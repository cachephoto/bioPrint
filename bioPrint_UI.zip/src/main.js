import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';
import { 
    initPanelText, 
    createPanelText, 
    handleTextInput, 
    startTextEditing, 
    stopTextEditing 
} from './panelText.js';

// Manejar el splash screen
document.addEventListener('DOMContentLoaded', () => {
  const splashScreen = document.getElementById('splash-screen');
  const appContainer = document.querySelector('.app-container');
  const loadingDots = document.getElementById('loading-dots');
  
  // Asegurar que el grid se animará en la primera creación
  isFirstGridCreation = true;
  
  // Animar los puntos suspensivos
  let dotCount = 0;
  const dotInterval = setInterval(() => {
    dotCount = (dotCount % 3) + 1;
    loadingDots.textContent = 'Iniciando' + '.'.repeat(dotCount) + ' '.repeat(3 - dotCount);
  }, 500);
  
  // Crear un div negro que cubra toda la pantalla hasta que comience la animación
  const blackOverlay = document.createElement('div');
  blackOverlay.style.position = 'fixed';
  blackOverlay.style.top = '0';
  blackOverlay.style.left = '0';
  blackOverlay.style.width = '100%';
  blackOverlay.style.height = '100%';
  blackOverlay.style.backgroundColor = '#000';
  blackOverlay.style.zIndex = '1000'; // Por debajo del splash pero por encima de la escena
  blackOverlay.id = 'black-overlay';
  document.body.appendChild(blackOverlay);
  
  // Mostrar la aplicación después de 3 segundos
  setTimeout(() => {
    clearInterval(dotInterval);
    splashScreen.style.opacity = '0';
    appContainer.style.opacity = '1';
    
    // Remover el splash screen después de la transición
    setTimeout(() => {
      splashScreen.style.display = 'none';
      
      // Limpiar completamente cualquier grid existente
      if (currentGrid) {
        scene.remove(currentGrid);
        currentGrid = null;
      }
      
      // Esperar un momento antes de iniciar la animación del grid
      setTimeout(() => {
        // Eliminar el overlay negro justo antes de empezar la animación
        document.body.removeChild(blackOverlay);
        
        // Iniciar la animación de 24 cuadros
        startGridAnimation24Frames();
      }, 200);
      
    }, 500);
  }, 3000);
});

// Variables para la animación de 24 cuadros
let animationFrame = 0;
const totalFrames = 24;
let animationInterval = null;

// Función para iniciar la animación de 24 cuadros del grid
function startGridAnimation24Frames() {
    console.log("Iniciando animación de 24 cuadros");
    
    // Resetear contador
    animationFrame = 0;
    
    // Asegurarse una vez más de que no hay grid
    if (currentGrid) {
        scene.remove(currentGrid);
        currentGrid = null;
    }
    
    // Iniciar intervalo para crear un nuevo grid en cada cuadro
    animationInterval = setInterval(() => {
        // Incrementar contador
        animationFrame++;
        
        // La subdivisión es igual al número de cuadro multiplicado por 2
        const subdivisions = animationFrame * 2;
        
        console.log(`Cuadro ${animationFrame}: Grid con ${subdivisions} subdivisiones`);
        
        // Remover grid anterior si existe
        if (currentGrid) {
            scene.remove(currentGrid);
        }
        
        // Crear nuevo grid con las subdivisiones actuales
        currentGrid = createGridSimple(subdivisions);
        scene.add(currentGrid);
        
        // Si llegamos al último cuadro, detener animación
        if (animationFrame >= totalFrames) {
            clearInterval(animationInterval);
            console.log("Animación de 24 cuadros completada - Se mantiene en 48 subdivisiones");
            
            // Establecer a 48 como nivel final después de la animación
            currentDivisions = 48;
            
            // Guardar configuración de cámara
            initialCameraState.position = camera.position.clone();
            initialCameraState.zoom = camera.zoom;
            initialCameraState.distance = camera.position.distanceTo(new THREE.Vector3(0, 0, 0));
            
            // Actualizar estado
            isFirstGridCreation = false;
        }
    }, 50); // 50ms por cuadro = 1.2 segundos total (el doble de rápido)
}

// Función simplificada para crear un grid con N subdivisiones
function createGridSimple(divisions, color = 0x888888, visible = true) {
    const group = new THREE.Group();
    group.visible = visible;

    // Materiales
    const lineMaterial = new THREE.LineBasicMaterial({
        color: color,
        opacity: visible ? 0.5 : 0,
        transparent: true
    });
    
    const centerLineMaterial = new THREE.LineBasicMaterial({
        color: color,
        opacity: visible ? 1 : 0,
        transparent: true
    });
    
    const borderMaterial = new THREE.LineBasicMaterial({
        color: color,
        opacity: visible ? 0.5 : 0,
        transparent: true,
        linewidth: 2
    });
    
    // Calcular dimensiones base
    const { width, height } = calculateGridSize();
    const minDimension = Math.min(width, height);
    
    // Asegurar que el número de divisiones sea par
    divisions = Math.max(2, Math.floor(divisions / 2) * 2);
    
    // Calcular tamaño de celda basado en la dimensión más pequeña
    const cellSize = minDimension / divisions;
    
    // Calcular número de celdas necesarias para cubrir el área
    const cellsX = Math.ceil(width / cellSize);
    const cellsY = Math.ceil(height / cellSize);
    
    // Asegurar que el número de celdas sea par
    const adjustedCellsX = Math.ceil(cellsX / 2) * 2;
    const adjustedCellsY = Math.ceil(cellsY / 2) * 2;
    
    // Calcular dimensiones totales ajustadas
    const adjustedWidth = adjustedCellsX * cellSize;
    const adjustedHeight = adjustedCellsY * cellSize;
    
    // Calcular mitades exactas
    const halfWidth = adjustedWidth / 2;
    const halfHeight = adjustedHeight / 2;
    
    // Crear grupos
    const linesGroup = new THREE.Group();
    const borderGroup = new THREE.Group();
    
    // Índices de las líneas centrales
    const centerXIndex = adjustedCellsX / 2;
    const centerYIndex = adjustedCellsY / 2;
    
    // Añadir líneas verticales
    for (let i = 0; i <= adjustedCellsX; i++) {
        const x = -halfWidth + i * cellSize;
        const geometry = new THREE.BufferGeometry().setFromPoints([
            new THREE.Vector3(x, -halfHeight, 0),
            new THREE.Vector3(x, halfHeight, 0)
        ]);
        
        // Si es la línea central
        if (i === centerXIndex) {
            const centerLine1 = new THREE.Line(geometry, centerLineMaterial);
            const centerLine2 = new THREE.Line(geometry, centerLineMaterial);
            // Desplazar ligeramente la segunda línea
            centerLine2.position.z = 0.001;
            linesGroup.add(centerLine1);
            linesGroup.add(centerLine2);
        } else {
            const line = new THREE.Line(geometry, lineMaterial.clone());
            linesGroup.add(line);
        }
    }
    
    // Añadir líneas horizontales
    for (let i = 0; i <= adjustedCellsY; i++) {
        const y = -halfHeight + i * cellSize;
        const geometry = new THREE.BufferGeometry().setFromPoints([
            new THREE.Vector3(-halfWidth, y, 0),
            new THREE.Vector3(halfWidth, y, 0)
        ]);
        
        // Si es la línea central
        if (i === centerYIndex) {
            const centerLine1 = new THREE.Line(geometry, centerLineMaterial);
            const centerLine2 = new THREE.Line(geometry, centerLineMaterial);
            // Desplazar ligeramente la segunda línea
            centerLine2.position.z = 0.001;
            linesGroup.add(centerLine1);
            linesGroup.add(centerLine2);
        } else {
            const line = new THREE.Line(geometry, lineMaterial.clone());
            linesGroup.add(line);
        }
    }
    
    // Añadir borde
    const bevelSize = cellSize * 0.5;
    const borderGeometry = new THREE.BufferGeometry().setFromPoints([
        // Lado izquierdo
        new THREE.Vector3(-halfWidth, -halfHeight + bevelSize, 0),
        new THREE.Vector3(-halfWidth, halfHeight - bevelSize, 0),
        // Esquina superior izquierda
        new THREE.Vector3(-halfWidth + bevelSize, halfHeight, 0),
        // Lado superior
        new THREE.Vector3(halfWidth - bevelSize, halfHeight, 0),
        // Esquina superior derecha
        new THREE.Vector3(halfWidth, halfHeight - bevelSize, 0),
        // Lado derecho
        new THREE.Vector3(halfWidth, -halfHeight + bevelSize, 0),
        // Esquina inferior derecha (bisel)
        new THREE.Vector3(halfWidth - bevelSize, -halfHeight, 0),
        // Lado inferior
        new THREE.Vector3(-halfWidth + bevelSize, -halfHeight, 0),
        // Cerrar el bucle
        new THREE.Vector3(-halfWidth, -halfHeight + bevelSize, 0)
    ]);
    
    const borderLine = new THREE.Line(borderGeometry, borderMaterial.clone());
    borderGroup.add(borderLine);
    
    // Añadir segunda línea para simular grosor
    const borderLine2 = borderLine.clone();
    borderLine2.scale.set(1.03, 1.03, 1.03);
    borderGroup.add(borderLine2);
    
    // Añadir grupos al principal
    group.add(linesGroup);
    group.add(borderGroup);
    
    // Guardar metadatos
    group.userData = {
        linesGroup,
        borderGroup,
        borderLines: [borderLine, borderLine2],
        cellSize,
        halfWidth,
        halfHeight,
        cellsX: adjustedCellsX,
        cellsY: adjustedCellsY
    };
    
    return group;
}

// Configuración de la escena
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000); // Negro

// Variables para recordar la configuración inicial de la cámara
const initialCameraState = {
    position: null,
    zoom: null,
    distance: null
};

// Contador global para número de orden de los paneles
let panelOrderCounter = 1;

// Configuración de la cámara perspectiva
const camera = new THREE.PerspectiveCamera(
    75,
    window.innerWidth / window.innerHeight,
    0.1,
    1000
);
camera.position.set(0, 0, 5);
camera.lookAt(0, 0, 0);

// Configuración del renderizador
const renderer = new THREE.WebGLRenderer({ 
    antialias: true,
    alpha: false
});
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(window.devicePixelRatio);
renderer.setClearColor(0x282828, 1);
document.body.appendChild(renderer.domElement);

// Variables globales para el grid
let currentGrid = null;
let currentDivisions = 1; // Estado natural: 1 subdivisión
const margin = 0.05;

// Variables para selección
const raycaster = new THREE.Raycaster();
// Configurar raycaster con mayor precisión
raycaster.params.Line.threshold = 0.02; // Umbral más preciso para líneas
raycaster.params.Points.threshold = 0.01; // Umbral más preciso para puntos
const mouse = new THREE.Vector2();
let isSelecting = false;
let startPoint = { x: 0, y: 0 };
let endPoint = { x: 0, y: 0 };
const selectionBox = document.getElementById('selection-box');
const panels = []; // Almacenar objetos de panel: { mesh, minCellIndex, maxCellIndex, selected, hovered }

// Materiales para los paneles (Mesh - ahora obsoletos, los dejamos por si acaso)
/* ... MeshMaterials ... */

// NUEVO: Materiales de LÍNEA para los paneles (Escala de Grises)
const panelLineMaterialNormal = new THREE.LineBasicMaterial({ 
    color: 0xaaaaaa, // Gris medio
    linewidth: 1 // Nota: linewidth no funciona en WebGL
});
const panelLineMaterialHover = new THREE.LineBasicMaterial({ 
    color: 0xcccccc, // Gris claro
    linewidth: 1
});
const panelLineMaterialSelected = new THREE.LineBasicMaterial({ 
    color: 0xffffff, // Blanco
    linewidth: 2 // Más grueso al seleccionar
});

// NUEVO: Materiales de RELLENO para los paneles (Escala de Grises)
const panelFillMaterialNormal = new THREE.MeshBasicMaterial({ 
    color: 0xaaaaaa, // Gris medio
    transparent: true, 
    opacity: 0.2, // Más transparente que las líneas
    side: THREE.DoubleSide 
});
const panelFillMaterialHover = new THREE.MeshBasicMaterial({ 
    color: 0xcccccc, // Gris claro
    transparent: true, 
    opacity: 0.3, 
    side: THREE.DoubleSide 
});
const panelFillMaterialSelected = new THREE.MeshBasicMaterial({ 
    color: 0xffffff, // Blanco
    transparent: true, 
    opacity: 0.4, 
    side: THREE.DoubleSide 
});

let pendingBoundingBox = null; // Para almacenar el bbox al cambiar resolución
let currentlyHoveredPanel = null;

// Variables para la animación del grid
let gridAnimationInProgress = false;
let gridAnimationStep = 0;
let gridAnimationProgress = 0;
let gridFlashCount = 0;
let isFirstGridCreation = true; // Nueva variable para detectar primera creación
let gridAnimationProps = {
    targetScale: 1,
    borderOpacity: 1,
    linesOpacity: 0,
    flashIntensity: 0
};

// Variables para la animación de paneles
const panelsFlashing = new Set(); // Conjunto de paneles actualmente en animación flash
const panelsResizing = new Set(); // Conjunto de paneles en animación de cambio de forma

// Variables para drag & drop de paneles
let isDraggingPanel = false;
let draggedPanel = null;
let dragStartPosition = { x: 0, y: 0 };
let dragStartPanelPosition = { x: 0, y: 0 };
let dragStartCellIndices = { minX: 0, minY: 0, maxX: 0, maxY: 0 };
const dragSensitivity = 0.8; // Reducido para mayor precisión (era 3.0)
let dragSnapToGrid = true; // Nueva variable para activar/desactivar el ajuste a la cuadrícula
let dragStartTimer = null; // Temporizador para retrasar el inicio del arrastre
const dragStartDelay = 500; // 0.5 segundos de retraso para iniciar arrastre
let potentialDragPanel = null; // Panel potencial para arrastrar (durante el retraso)

// Variable para controlar la visibilidad de los controles
let controlsVisible = true;

// Variable para controlar la visibilidad de la consola terminal
let terminalVisible = false;

// Variables para almacenar estados de pantalla
const savedScreenStates = new Array(10).fill(null); // 10 slots para estados (0-9)
let lastSavedStateIndex = -1; // Último estado guardado

// Función para calcular el tamaño del grid basado en el aspecto del canvas
function calculateGridSize() {
    const aspect = window.innerWidth / window.innerHeight;
    const maxSize = 12; // Aumentado para compensar el margen reducido
    
    if (aspect > 1) {
        // Canvas más ancho que alto
        return {
            width: maxSize,
            height: maxSize / aspect
        };
    } else {
        // Canvas más alto que ancho
        return {
            width: maxSize * aspect,
            height: maxSize
        };
    }
}

// Función para crear el grid con biseles (Escala de Grises)
function createGrid(divisions, color = 0x888888, animate = true) { 
    // Si hay una animación en progreso, cancelarla
    gridAnimationInProgress = false;
    
    const group = new THREE.Group();
    
    // Si es la primera vez, usar opacity 0 para todo
    const initialOpacity = (animate && isFirstGridCreation) ? 0 : 1;
    
    const material = new THREE.LineBasicMaterial({ 
        color: color,
        transparent: true,
        opacity: initialOpacity
    });
    
    const borderMaterial = new THREE.LineBasicMaterial({ 
        color: color,
        transparent: true,
        opacity: initialOpacity,
        linewidth: 2 
    });
    
    const { width, height } = calculateGridSize();
    
    // Calcular el tamaño de celda basado en la dimensión más pequeña
    const minDimension = Math.min(width, height);
    const cellSize = minDimension / divisions;
    
    // Calcular el número de celdas en cada dirección
    const cellsX = Math.ceil(width / cellSize);
    const cellsY = Math.ceil(height / cellSize);
    
    // Ajustar el tamaño total para que sea múltiplo del tamaño de celda
    const adjustedWidth = cellsX * cellSize;
    const adjustedHeight = cellsY * cellSize;
    
    const halfWidth = adjustedWidth / 2;
    const halfHeight = adjustedHeight / 2;
    
    // Tamaño del bisel (mitad del tamaño de la celda)
    const bevelSize = cellSize * 0.5;
    
    // Grupo para las líneas internas (separado para animar)
    const linesGroup = new THREE.Group();
    group.add(linesGroup);
    
    // Crear líneas verticales internas
    for (let i = 1; i < cellsX; i++) {
        const x = -halfWidth + (i * cellSize);
        
        const points = [];
        points.push(new THREE.Vector3(x, -halfHeight, 0));
        points.push(new THREE.Vector3(x, halfHeight, 0));
        
        const geometry = new THREE.BufferGeometry().setFromPoints(points);
        const line = new THREE.Line(geometry, material.clone());
        linesGroup.add(line);
    }
    
    // Crear líneas horizontales internas
    for (let i = 1; i < cellsY; i++) {
        const y = -halfHeight + (i * cellSize);
        
        const points = [];
        points.push(new THREE.Vector3(-halfWidth, y, 0));
        points.push(new THREE.Vector3(halfWidth, y, 0));
        
        const geometry = new THREE.BufferGeometry().setFromPoints(points);
        const line = new THREE.Line(geometry, material.clone());
        linesGroup.add(line);
    }
    
    // Grupo para el borde (separado para animar)
    const borderGroup = new THREE.Group();
    group.add(borderGroup);
    
    // Crear borde grueso
    const borderPoints = [];
    
    // Lado izquierdo
    borderPoints.push(new THREE.Vector3(-halfWidth, -halfHeight + bevelSize, 0));
    borderPoints.push(new THREE.Vector3(-halfWidth, halfHeight - bevelSize, 0));
    
    // Esquina superior izquierda (bisel)
    borderPoints.push(new THREE.Vector3(-halfWidth + bevelSize, halfHeight, 0));
    
    // Lado superior
    borderPoints.push(new THREE.Vector3(halfWidth - bevelSize, halfHeight, 0));
    
    // Esquina superior derecha (bisel)
    borderPoints.push(new THREE.Vector3(halfWidth, halfHeight - bevelSize, 0));
    
    // Lado derecho
    borderPoints.push(new THREE.Vector3(halfWidth, -halfHeight + bevelSize, 0));
    
    // Esquina inferior derecha (bisel)
    borderPoints.push(new THREE.Vector3(halfWidth - bevelSize, -halfHeight, 0));
    
    // Lado inferior
    borderPoints.push(new THREE.Vector3(-halfWidth + bevelSize, -halfHeight, 0));
    
    // Esquina inferior izquierda (bisel)
    borderPoints.push(new THREE.Vector3(-halfWidth, -halfHeight + bevelSize, 0));
    
    const borderGeometry = new THREE.BufferGeometry().setFromPoints(borderPoints);
    const borderLine = new THREE.Line(borderGeometry, borderMaterial.clone());
    
    // Crear una segunda línea para el borde para simular grosor
    const borderLine2 = borderLine.clone();
    borderLine2.scale.set(1.03, 1.03, 1.03);
    
    borderGroup.add(borderLine);
    borderGroup.add(borderLine2);
    
    // Guardar referencias para la animación
    group.userData = {
        borderGroup,
        linesGroup,
        borderLines: [borderLine, borderLine2]
    };
    
    // Agregar animación solo si es primera vez o se solicita explícitamente
    if (animate && isFirstGridCreation) {
        // Iniciar con escala pequeña para animación y opacidad 0
        group.scale.set(0.01, 0.01, 0.01);
        
        // Asegurar que todas las líneas son invisibles inicialmente
        linesGroup.children.forEach(line => {
            line.material.opacity = 0;
        });
        
        borderGroup.children.forEach(line => {
            line.material.opacity = 0;
        });
        
        // Configurar animación
        gridAnimationInProgress = true;
        gridAnimationStep = 0; // Comenzar desde el paso 0 (crecimiento)
        gridAnimationProgress = 0;
        gridFlashCount = 0;
        
        // Propiedades de animación
        gridAnimationProps = {
            targetScale: 1,
            borderOpacity: 1,
            linesOpacity: 1,
            flashIntensity: 0.3
        };
        
        console.log("Animación del grid configurada, isFirstGridCreation:", isFirstGridCreation);
    } else {
        // Sin animación, establecer valores finales
        group.scale.set(1, 1, 1);
        
        // Actualizar opacidad de líneas y bordes a 1
        linesGroup.children.forEach(line => {
            line.material.opacity = 1;
        });
        
        borderGroup.children.forEach(line => {
            line.material.opacity = 1;
        });
    }
    
    // No establecer isFirstGridCreation en false aquí
    // Solo lo haremos después de completar la animación
    
    return group;
}

// Crear el grid principal
// NO crear el grid aquí - se creará después del splash screen
// currentGrid = createGrid(currentDivisions);
// scene.add(currentGrid);
// Marcar que ya pasó la primera creación después de crear el grid inicial
// isFirstGridCreation = false;

// Guardar configuración inicial de la cámara (después de crear todo)
initialCameraState.position = camera.position.clone();
initialCameraState.zoom = camera.zoom;
initialCameraState.distance = camera.position.distanceTo(new THREE.Vector3(0, 0, 0));

// Controles de órbita
const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.05;
controls.screenSpacePanning = true;

// Cambiar activación a Ctrl + Click izquierdo
controls.mouseButtons = {
	LEFT: THREE.MOUSE.PAN, // Pan con click izquierdo normal
	MIDDLE: THREE.MOUSE.DOLLY, // Zoom con rueda
	RIGHT: THREE.MOUSE.PAN // Pan también con click derecho (opcional)
}
controls.touches = {
	ONE: THREE.TOUCH.PAN,
	TWO: THREE.TOUCH.DOLLY_PAN
}
// La rotación ahora requiere presionar Ctrl
controls.enableRotate = true; // Habilitar rotación

// Limitar la rotación a 8 grados (en radianes)
const maxRotation = (8 * Math.PI) / 180;
controls.minPolarAngle = Math.PI/2 - maxRotation;
controls.maxPolarAngle = Math.PI/2 + maxRotation;
controls.minAzimuthAngle = -maxRotation;
controls.maxAzimuthAngle = maxRotation;

// Limitar el zoom
controls.minDistance = 4; // Distancia mínima de la cámara
controls.maxDistance = 8; // Distancia máxima de la cámara
controls.zoomSpeed = 0.5; // Reducir la velocidad del zoom


// Luz
const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
scene.add(ambientLight);

const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
directionalLight.position.set(5, 5, 5);
scene.add(directionalLight);

// Función para actualizar el grid Y los paneles
function updateGrid(newDivisions) {
    // Validar que el valor sea al menos 1 subdivisión
    newDivisions = Math.max(1, newDivisions);
    
    scene.remove(currentGrid);
    currentDivisions = newDivisions;
    
    console.log(`Actualizando grid a ${currentDivisions} subdivisiones`);
    
    // Crear el grid con las subdivisiones solicitadas (siempre visible)
    currentGrid = createGridSimple(currentDivisions, 0x888888, true);
    scene.add(currentGrid);

    // Actualizar paneles inmediatamente
    updatePanelsAfterGridAnimation();
}

// Función helper para comprobar conflictos al mover un panel
function checkPanelMoveConflict(panelToMove, dx, dy, gridParams) {
    const { cellsX, cellsY } = gridParams;
    const newMinX = panelToMove.minCellIndex.x + dx;
    const newMaxX = panelToMove.maxCellIndex.x + dx;
    const newMinY = panelToMove.minCellIndex.y + dy;
    const newMaxY = panelToMove.maxCellIndex.y + dy;

    // Comprobar límites del grid
    if (newMinX < 0 || newMaxX >= cellsX || newMinY < 0 || newMaxY >= cellsY) {
        //console.log("Move conflict: Out of bounds");
        return true; // Fuera de los límites
    }

    // Comprobar conflictos con otros paneles existentes (excepto él mismo y otros seleccionados que se moverán)
    const otherPanels = panels.filter(p => p !== panelToMove && !p.selected);
    for (const otherPanel of otherPanels) {
        const eMinX = otherPanel.minCellIndex.x;
        const eMaxX = otherPanel.maxCellIndex.x;
        const eMinY = otherPanel.minCellIndex.y;
        const eMaxY = otherPanel.maxCellIndex.y;

        // Comprobar si los nuevos índices (con margen de 1 celda) se solapan con el otro panel
        const conflictX = !(newMaxX < eMinX - 1 || newMinX > eMaxX + 1);
        const conflictY = !(newMaxY < eMinY - 1 || newMinY > eMaxY + 1);

        if (conflictX && conflictY) {
            //console.log("Move conflict: Panel collision");
            return true; // Conflicto con otro panel
        }
    }

    return false; // No hay conflictos
}

// Función para alternar la visibilidad de todos los controles
function toggleControlsVisibility() {
    controlsVisible = !controlsVisible;
    
    // Alternar visibilidad de #controls (botones principales)
    const controlsElement = document.getElementById('controls');
    if (controlsElement) {
        controlsElement.style.display = controlsVisible ? 'block' : 'none';
    }
    
    // Alternar visibilidad de #ui-controls (botones de estados)
    const uiControlsElement = document.getElementById('ui-controls');
    if (uiControlsElement) {
        uiControlsElement.style.display = controlsVisible ? 'flex' : 'none';
    }
    
    // Actualizar la variable global
    controlsVisible = controlsVisible;
}

// Control de teclado
document.addEventListener('keydown', (event) => {
    // Ignorar atajos de teclado si la terminal está visible, excepto Escape
    if (terminalVisible && event.key !== 'Escape') {
        return;
    }

    let newDivisions = currentDivisions;
    let resolutionChanged = false;
    let moveDelta = { dx: 0, dy: 0 };
    let deleteTriggered = false;

    switch (event.key) {
        case '+':
        case '=': // Tecla '+' a menudo comparte con '='
            newDivisions = Math.min(currentDivisions + 1, 50);
            resolutionChanged = true;
            break;
        case '-':
        case '_': // Tecla '-' a menudo comparte con '_'
            newDivisions = Math.max(currentDivisions - 1, 2);
            resolutionChanged = true;
            break;
        case 'ArrowUp':
            moveDelta.dy = 1;
            break;
        case 'ArrowDown':
            moveDelta.dy = -1;
            break;
        case 'ArrowLeft':
            moveDelta.dx = -1;
            break;
        case 'ArrowRight':
            moveDelta.dx = 1;
            break;
        case 'x':
        case 'X':
        case 'Delete': // Añadir tecla Supr
            deleteTriggered = true;
            break;
        case 'c':
        case 'C':
            // Limpiar TODOS los paneles
            clearAllPanels();
            return;
        case 'a':
        case 'A':
            // Centrar grid en la cámara
            centerGridInCamera();
            return;
        case 'v':
        case 'V':
            // Alternar visibilidad de controles
            toggleControlsVisibility();
            return;
        case 't':
        case 'T':
            // Mostrar u ocultar la consola terminal
            event.preventDefault(); // Prevenir el comportamiento por defecto
            toggleTerminal(true);
            return;
        case 'Escape':
            // Mostrar u ocultar la consola terminal
            toggleTerminal(false);
            return;
    }

    // --- Procesar Cambio de Resolución --- 
    if (resolutionChanged && newDivisions !== currentDivisions) {
        // NO eliminamos los grupos de paneles de la escena aquí.
        // updateGrid se encargará de actualizar su contenido y posición.
        updateGrid(newDivisions); 
    }
    
    // --- Procesar Movimiento --- 
    else if (moveDelta.dx !== 0 || moveDelta.dy !== 0) {
        const selectedPanels = panels.filter(p => p.selected);
        if (selectedPanels.length > 0) {
            const currentGridParams = getCurrentGridParams();
            if (!currentGridParams) return;

            // Comprobar si TODOS los paneles seleccionados pueden moverse
            let canMoveAll = true;
            for (const panel of selectedPanels) {
                if (checkPanelMoveConflict(panel, moveDelta.dx, moveDelta.dy, currentGridParams)) {
                    canMoveAll = false;
                    break;
                }
            }

            // Si todos pueden moverse, actualizar sus índices y geometría/posición
            if (canMoveAll) {
                selectedPanels.forEach(panel => {
                    panel.minCellIndex.x += moveDelta.dx;
                    panel.maxCellIndex.x += moveDelta.dx;
                    panel.minCellIndex.y += moveDelta.dy;
                    panel.maxCellIndex.y += moveDelta.dy;
                    updatePanelGeometryAndPosition(panel, currentGridParams); // Actualizar mesh
                });
            } else {
                 console.warn("Movimiento cancelado: Conflicto de límites o colisión.");
            }
        }
    }

    // --- Procesar Borrado --- 
    else if (deleteTriggered) {
        const remainingPanels = [];
        let deletedSomething = false;
        panels.forEach(panel => {
            if (panel.selected) {
                if(panel.group) {
                    scene.remove(panel.group);
                    // Limpiar geometrías de los hijos (líneas)
                    while(panel.group.children.length > 0){
                         const child = panel.group.children[0]; 
                         panel.group.remove(child);
                         if (child.geometry) child.geometry.dispose();
                     }
                }
                if (panel === currentlyHoveredPanel) {
                     currentlyHoveredPanel = null; 
                }
                deletedSomething = true;
            } else {
                remainingPanels.push(panel);
            }
        });
        if(deletedSomething) {
            panels.length = 0; 
            panels.push(...remainingPanels); 
        }
    }

    // Desactivar snap to grid mientras se presiona Shift durante arrastre
    if (event.key === 'Shift' && isDraggingPanel) {
        dragSnapToGrid = false;
    }
});

document.addEventListener('keyup', (event) => {
    // Reactivar snap to grid al soltar Shift
    if (event.key === 'Shift' && isDraggingPanel) {
        dragSnapToGrid = true;
    }
});

// Función de animación
function animate() {
    requestAnimationFrame(animate);
    
    // Animar el grid si hay una animación en progreso
    if (gridAnimationInProgress) {
        animateGrid();
    }
    
    // Animar paneles cambiando de forma
    if (panelsResizing.size > 0) {
        animateResizingPanels();
    }
    
    // Animar paneles en flash si hay alguno
    if (panelsFlashing.size > 0) {
        animateFlashingPanels();
    }
    
    controls.update();
    renderer.render(scene, camera);
}
animate();

// Manejo del redimensionamiento
function handleResize() {
    const width = window.innerWidth;
    const height = window.innerHeight;
    
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    renderer.setSize(width, height);
    
    // Actualizar el grid Y adaptar paneles existentes (sin BBox)
    updateGrid(currentDivisions);
}

window.addEventListener('resize', handleResize);

// Exportar funciones para controlar el grid desde la consola
window.updateGrid = updateGrid;

// Función para obtener la posición 3D en el plano del grid
function get3DPointOnGrid(event) {
    // Calcular coordenadas precisas del mouse
    mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
    
    // Configurar raycaster con la cámara y las coordenadas del mouse
    raycaster.setFromCamera(mouse, camera);
    
    // Crear un plano imaginario en z=0 para la intersección
    const plane = new THREE.Plane(new THREE.Vector3(0, 0, 1), 0);
    const intersectionPoint = new THREE.Vector3();
    
    // Calcular intersección con mayor precisión
    const didIntersect = raycaster.ray.intersectPlane(plane, intersectionPoint);
    
    // Aplicar redondeo controlado para evitar imprecisiones por punto flotante
    if (didIntersect) {
        // Mantener 4 decimales de precisión
        intersectionPoint.x = Math.round(intersectionPoint.x * 10000) / 10000;
        intersectionPoint.y = Math.round(intersectionPoint.y * 10000) / 10000;
        intersectionPoint.z = 0; // Asegurar que Z es exactamente 0
    }
    
    return intersectionPoint;
}

// Función para crear paneles
function createPanelFromSelection(start3D, end3D) {
    const currentGridParams = getCurrentGridParams(); // Obtener parámetros actuales
    if (!currentGridParams) return;
    const { cellSize, cellsX, cellsY, halfWidth, halfHeight } = currentGridParams;

    // Determinar límites de la selección en 3D
    const minX = Math.min(start3D.x, end3D.x);
    const maxX = Math.max(start3D.x, end3D.x);
    const minY = Math.min(start3D.y, end3D.y);
    const maxY = Math.max(start3D.y, end3D.y);

    // Encontrar celdas seleccionadas y sus índices
    const selectedCellIndices = [];
    let pMinX = Infinity, pMaxX = -Infinity;
    let pMinY = Infinity, pMaxY = -Infinity;

    for (let i = 0; i < cellsX; i++) {
        for (let j = 0; j < cellsY; j++) {
            const cellCenterX = -halfWidth + (i + 0.5) * cellSize;
            const cellCenterY = -halfHeight + (j + 0.5) * cellSize;
            
            if (cellCenterX >= minX && cellCenterX <= maxX && 
                cellCenterY >= minY && cellCenterY <= maxY) {
                selectedCellIndices.push({ i, j });
                pMinX = Math.min(pMinX, i);
                pMaxX = Math.max(pMaxX, i);
                pMinY = Math.min(pMinY, j);
                pMaxY = Math.max(pMaxY, j);
            }
        }
    }

    if (selectedCellIndices.length === 0) return; // No se seleccionó ninguna celda

    // *** Inicio: Comprobación de conflictos ***
    for (const existingPanel of panels) {
        const eMinX = existingPanel.minCellIndex.x;
        const eMaxX = existingPanel.maxCellIndex.x;
        const eMinY = existingPanel.minCellIndex.y;
        const eMaxY = existingPanel.maxCellIndex.y;

        // Comprobar si los rectángulos de índices (con margen de 1 celda) se solapan
        const conflictX = !(pMaxX < eMinX - 1 || pMinX > eMaxX + 1);
        const conflictY = !(pMaxY < eMinY - 1 || pMinY > eMaxY + 1);

        if (conflictX && conflictY) {
            console.warn("Creación de panel cancelada: Conflicto con panel existente.");
            return; // Detener la creación si hay conflicto
        }
    }
    // *** Fin: Comprobación de conflictos ***

    // Crear el objeto panel (sin mesh ni group inicial)
    const panelData = {
        group: null, // Usaremos group en lugar de mesh
        minCellIndex: { x: pMinX, y: pMinY },
        maxCellIndex: { x: pMaxX, y: pMaxY },
        orderNumber: panelOrderCounter++, // Asignar número de orden
        showOrderNumber: true // Por defecto, mostrar el número
    };

    // Calcular y asignar geometría/posición inicial (ahora crea el group y líneas)
    updatePanelGeometryAndPosition(panelData, currentGridParams);

    if(panelData.group) { // Comprobar si el grupo se creó
        scene.add(panelData.group); // Añadir el grupo a la escena
        panels.push(panelData); // Almacenar el objeto completo
        
        // El flash ya se inicia en updatePanelGeometryAndPosition
        
        // Crear etiqueta con número de orden
        createPanelOrderLabel(panelData);
    }
}

// Nueva función para crear la etiqueta con el número de orden
function createPanelOrderLabel(panelData) {
    if (!panelData.group) return;
    
    // Eliminar etiqueta anterior si existe
    if (panelData.orderLabel) {
        panelData.group.remove(panelData.orderLabel);
    }
    
    // Solo crear etiqueta si showOrderNumber es true
    if (panelData.showOrderNumber) {
        // Crear canvas para la etiqueta
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        canvas.width = 64;
        canvas.height = 64;
        
        // Estilo del número
        context.fillStyle = '#000000';
        context.fillRect(0, 0, canvas.width, canvas.height);
        context.fillStyle = '#ffffff';
        context.font = 'bold 40px Arial';
        context.textAlign = 'center';
        context.textBaseline = 'middle';
        context.fillText(panelData.orderNumber.toString(), canvas.width/2, canvas.height/2);
        
        // Crear textura y sprite
        const texture = new THREE.CanvasTexture(canvas);
        const material = new THREE.SpriteMaterial({ map: texture });
        const sprite = new THREE.Sprite(material);
        
        // Ajustar tamaño y posición
        sprite.scale.set(0.2, 0.2, 1);
        sprite.position.set(0, 0, 0.02); // Ligeramente por encima del panel
        
        // Guardar referencia y añadir al grupo
        panelData.orderLabel = sprite;
        panelData.group.add(sprite);
    }
}

// Función para obtener parámetros actuales del grid
function getCurrentGridParams() {
    if (!currentGrid) return null;
    const { width, height } = calculateGridSize();
    const minDimension = Math.min(width, height);
    const cellSize = minDimension / currentDivisions;
    const cellsX = Math.ceil(width / cellSize);
    const cellsY = Math.ceil(height / cellSize);
    const adjustedWidth = cellsX * cellSize;
    const adjustedHeight = cellsY * cellSize;
    const halfWidth = adjustedWidth / 2;
    const halfHeight = adjustedHeight / 2;
    return { width, height, minDimension, cellSize, cellsX, cellsY, adjustedWidth, adjustedHeight, halfWidth, halfHeight };
}

// Función para actualizar la geometría y posición de UN panel
function updatePanelGeometryAndPosition(panelData, gridParams) {
    const { cellSize, halfWidth, halfHeight } = gridParams;
    const { minCellIndex, maxCellIndex } = panelData;

    // Preservar el número de orden y visibilidad
    const orderNumber = panelData.orderNumber;
    const showOrderNumber = panelData.showOrderNumber !== undefined ? panelData.showOrderNumber : true;

    const panelCellsX = maxCellIndex.x - minCellIndex.x + 1;
    const panelCellsY = maxCellIndex.y - minCellIndex.y + 1;

    const panelWidth = panelCellsX * cellSize;
    const panelHeight = panelCellsY * cellSize;
    
    // Calcular centro basado en índices y tamaño de celda actual
    const panelCenterX = -halfWidth + (minCellIndex.x + panelCellsX / 2) * cellSize;
    const panelCenterY = -halfHeight + (minCellIndex.y + panelCellsY / 2) * cellSize;

    const panelHalfWidth = panelWidth / 2;
    const panelHalfHeight = panelHeight / 2;
    const bevelSize = cellSize * 0.5;

    // Si el grupo no existe, crearlo
    if (!panelData.group) {
        panelData.group = new THREE.Group();
        panelData.group.userData = { panelDataRef: panelData }; 
        panelData.selected = false; 
        panelData.hovered = false; 
        panelData.borderLines = []; // Inicializar array para líneas de borde
    } else {
        // Limpiar hijos antiguos (incluyendo líneas de borde antiguas)
        while(panelData.group.children.length > 0){
            const child = panelData.group.children[0]; 
            panelData.group.remove(child);
            if (child.geometry) child.geometry.dispose();
            if (child === panelData.fillMesh) {
                 delete panelData.fillMesh;
            }
        }
        panelData.borderLines = []; // Resetear array para nuevas líneas
        delete panelData.orderLabel; // Eliminar referencia a la etiqueta eliminada
    }

    // Asegurarnos de que se mantenga el número de orden
    panelData.orderNumber = orderNumber;
    panelData.showOrderNumber = showOrderNumber;

    // --- Crear/Actualizar Mesh de Relleno con Forma Biselada --- 
    const shape = new THREE.Shape();

    // Empezar en esquina inf izq (después del bisel)
    shape.moveTo(-panelHalfWidth + bevelSize, -panelHalfHeight);
    // Lado inferior
    shape.lineTo(panelHalfWidth - bevelSize, -panelHalfHeight);
    // Esquina inf der (bisel)
    shape.lineTo(panelHalfWidth, -panelHalfHeight + bevelSize);
    // Lado derecho
    shape.lineTo(panelHalfWidth, panelHalfHeight - bevelSize);
    // Esquina sup der (bisel)
    shape.lineTo(panelHalfWidth - bevelSize, panelHalfHeight);
    // Lado superior
    shape.lineTo(-panelHalfWidth + bevelSize, panelHalfHeight);
    // Esquina sup izq (bisel)
    shape.lineTo(-panelHalfWidth, panelHalfHeight - bevelSize);
    // Lado izquierdo
    shape.lineTo(-panelHalfWidth, -panelHalfHeight + bevelSize);
    // Cerrar (vuelve al punto inicial)
    shape.closePath();

    const fillGeometry = new THREE.ShapeGeometry(shape);
    panelData.fillMesh = new THREE.Mesh(fillGeometry, panelFillMaterialNormal);
    panelData.fillMesh.position.set(0, 0, 0); 
    // Añadir referencia al panel para detectar clics en el relleno directamente
    panelData.fillMesh.userData.panelDataRef = panelData;
    panelData.fillMesh.userData.isPanel = true;
    panelData.group.add(panelData.fillMesh); 
    // --- Fin Relleno --- 

    // --- Crear Líneas de Borde (una única línea) --- 
    const borderPoints = [];
    // Izquierdo
    borderPoints.push(new THREE.Vector3(-panelHalfWidth, -panelHalfHeight + bevelSize, 0));
    borderPoints.push(new THREE.Vector3(-panelHalfWidth, panelHalfHeight - bevelSize, 0));
    // Sup Izq (bisel)
    borderPoints.push(new THREE.Vector3(-panelHalfWidth + bevelSize, panelHalfHeight, 0));
    // Superior
    borderPoints.push(new THREE.Vector3(panelHalfWidth - bevelSize, panelHalfHeight, 0));
    // Sup Der (bisel)
    borderPoints.push(new THREE.Vector3(panelHalfWidth, panelHalfHeight - bevelSize, 0));
    // Derecho
    borderPoints.push(new THREE.Vector3(panelHalfWidth, -panelHalfHeight + bevelSize, 0));
    // Inf Der (bisel)
    borderPoints.push(new THREE.Vector3(panelHalfWidth - bevelSize, -panelHalfHeight, 0));
    // Inferior
    borderPoints.push(new THREE.Vector3(-panelHalfWidth + bevelSize, -panelHalfHeight, 0));
    // Inf Izq (bisel) y cerrar
    borderPoints.push(new THREE.Vector3(-panelHalfWidth, -panelHalfHeight + bevelSize, 0));

    const borderGeometry = new THREE.BufferGeometry().setFromPoints(borderPoints);
    // Establecer un valor alto para computeBoundingSphere para mejorar la detección con raycaster
    borderGeometry.computeBoundingSphere();
    
    // Crear SOLO UNA línea de borde
    const borderLine = new THREE.Line(borderGeometry, panelLineMaterialNormal);
    // Mejorar la detección para raycasting
    borderLine.userData.isPanel = true; // Marcador para identificar líneas de panel
    panelData.group.add(borderLine);
    panelData.borderLines.push(borderLine);
    
    // Ya no creamos la segunda línea
    
    // Posicionar el GRUPO en el centro calculado
    panelData.group.position.set(panelCenterX, panelCenterY, 0.01); 

    if (panelData.mesh) delete panelData.mesh; 

    // Preparar animación de flash
    panelData.flashProgress = 0;
    panelData.shouldFlash = true;
    panelsFlashing.add(panelData);
    
    // Recrear etiqueta de número de orden
    createPanelOrderLabel(panelData);
    
    // Después de actualizar la geometría del panel, actualizar el texto si existe
    createPanelText(panelData, gridParams.cellSize);
}

// Función para crear UN panel desde bounding box de índices
function createPanelFromBoundingBox(bboxIndices, gridParams) {
     const panelData = {
        mesh: null,
        minCellIndex: { x: bboxIndices.minX, y: bboxIndices.minY },
        maxCellIndex: { x: bboxIndices.maxX, y: bboxIndices.maxY },
        orderNumber: panelOrderCounter++, // Asignar número de orden
        showOrderNumber: true // Por defecto, mostrar el número
    };
    updatePanelGeometryAndPosition(panelData, gridParams);
     if(panelData.mesh) {
        scene.add(panelData.mesh);
        panels.push(panelData); // Almacenar el nuevo panel único
        
        // Crear etiqueta con número de orden
        createPanelOrderLabel(panelData);
    }
}

// Función helper para actualizar el color del panel (AHORA PARA LÍNEAS Y RELLENO)
function updatePanelColor(panelData) {
    if (!panelData || !panelData.group) return;
    
    let targetLineMaterial;
    let targetFillMaterial;

    if (panelData.selected) {
        targetLineMaterial = panelLineMaterialSelected;
        targetFillMaterial = panelFillMaterialSelected;
    } else if (panelData.hovered) {
        targetLineMaterial = panelLineMaterialHover;
        targetFillMaterial = panelFillMaterialHover;
    } else {
        targetLineMaterial = panelLineMaterialNormal;
        targetFillMaterial = panelFillMaterialNormal;
    }

    // Aplicar el material a todas las líneas dentro del grupo
    panelData.group.children.forEach(child => {
        if (child instanceof THREE.Line) {
            child.material = targetLineMaterial;
        } 
        // Aplicar al mesh de relleno si existe
        else if (child === panelData.fillMesh) { 
             child.material = targetFillMaterial;
        }
    });

    // Guardar referencia a materiales actuales para animación de flash
    panelData.currentLineMaterial = targetLineMaterial;
    panelData.currentFillMaterial = targetFillMaterial;
}

// Event listeners para selección
renderer.domElement.addEventListener('mousedown', (event) => {
    // Permitir solo click izquierdo sin Ctrl
    if (event.button === 0 && !event.ctrlKey) {
        mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
        mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
        
        // Configurar raycaster con posición precisa
        raycaster.setFromCamera(mouse, camera);

        // --- Raycast contra BORDES Y RELLENO --- 
        // Recopilar todos los objetos seleccionables (bordes y rellenos)
        const allSelectable = [];
        
        // Añadir todos los meshes de relleno (fillMesh)
        const allFillMeshes = panels.map(p => p.fillMesh).filter(Boolean);
        allSelectable.push(...allFillMeshes);
        
        // Añadir también las líneas de borde para mantener la selección precisa
        const allBorderLines = panels.flatMap(p => p.borderLines || []).filter(Boolean);
        allSelectable.push(...allBorderLines);
        
        // Ordenar por distancia más cercana primero
        const intersects = raycaster.intersectObjects(allSelectable, false)
            .sort((a, b) => a.distance - b.distance);

        if (intersects.length > 0) {
            // --- Se hizo click sobre un panel (borde o relleno) --- 
            // IMPORTANTE: Desactivar controles de cámara INMEDIATAMENTE al hacer clic en un panel
            // Esto evita que la cámara se mueva cuando queremos interactuar con paneles
            controls.enabled = false;
            
            let clickedPanelData = null;
            // El objeto intersectado es una línea o mesh, obtener panelData
            let currentObject = intersects[0].object;
            
            // Si es un fillMesh, podría tener referencia directa
            if (currentObject.userData && currentObject.userData.panelDataRef) {
                clickedPanelData = currentObject.userData.panelDataRef;
            } else {
                // Buscar hacia arriba en la jerarquía de objetos
                while (currentObject && !clickedPanelData) {
                    if (currentObject.userData && currentObject.userData.panelDataRef) {
                        clickedPanelData = currentObject.userData.panelDataRef;
                        break; // Salir del bucle inmediatamente al encontrar el panel
                    }
                    // Subir al padre solo si NO encontramos userData aquí
                    currentObject = currentObject.parent; 
                }
            }
            
            if (clickedPanelData) {
                // Guardar la posición inicial del mouse ahora
                const mouseStartPosition = { 
                    x: event.clientX, 
                    y: event.clientY 
                };
                
                // Guardar posición inicial del panel
                const panelStartPosition = { 
                    x: clickedPanelData.group.position.x, 
                    y: clickedPanelData.group.position.y 
                };
                
                // Guardar índices de celda iniciales
                const cellStartIndices = {
                    minX: clickedPanelData.minCellIndex.x,
                    minY: clickedPanelData.minCellIndex.y,
                    maxX: clickedPanelData.maxCellIndex.x,
                    maxY: clickedPanelData.maxCellIndex.y
                };
                
                // Procesar la selección de inmediato (no se espera para esto)
                if (event.shiftKey) {
                    // --- Shift + Click: Añadir/Quitar de la selección --- 
                    clickedPanelData.selected = !clickedPanelData.selected; 
                    updatePanelColor(clickedPanelData);
                } else {
                    // --- Click Normal: Seleccionar solo este, deseleccionar otros --- 
                    const wasAlreadySelected = clickedPanelData.selected;
                    // Deseleccionar todos primero
                    panels.forEach(p => {
                        if (p.selected) {
                            p.selected = false;
                            updatePanelColor(p);
                        }
                    });
                    // Seleccionar solo el clickeado (si no era el único ya seleccionado)
                    if (!wasAlreadySelected) {
                       clickedPanelData.selected = true; 
                       updatePanelColor(clickedPanelData);
                    } // Si ya era el único seleccionado, el efecto es deseleccionarlo (ya hecho arriba)
                }
                
                // Configurar temporizador para iniciar el arrastre después del retraso
                // Cancelar cualquier temporizador existente primero
                if (dragStartTimer) {
                    clearTimeout(dragStartTimer);
                }
                
                // Guardar panel potencial para arrastrar
                potentialDragPanel = clickedPanelData;
                
                // Iniciar nuevo temporizador
                dragStartTimer = setTimeout(() => {
                    // Si todavía está presionado el botón del mouse después del retraso,
                    // iniciar el arrastre
                    if (potentialDragPanel) {
                        draggedPanel = potentialDragPanel;
                        isDraggingPanel = true;
                        
                        // Transferir valores guardados
                        dragStartPosition = mouseStartPosition;
                        dragStartPanelPosition = panelStartPosition;
                        dragStartCellIndices = cellStartIndices;
                        
                        // Cambiar cursor para indicar arrastre activo
                        renderer.domElement.style.cursor = 'move';
                    }
                }, dragStartDelay);
                
                return; // No iniciar selección de recuadro
            } else {
                 console.warn("Intersección detectada, pero no se encontró panelDataRef.");
                 // Reactivar controles si no se encontró un panel válido
                 controls.enabled = true;
            }
        } else {
            // --- Se hizo click en el fondo (no en un panel) --- 
            // Aquí SÍ permitimos el panning (los controles están habilitados por defecto)
            if (!event.shiftKey) { // Solo deseleccionar si NO se presiona Shift
                let deselectedSomething = false;
                panels.forEach(p => {
                    if (p.selected) {
                        p.selected = false;
                        updatePanelColor(p);
                        deselectedSomething = true;
                    }
                });
    
                // Si no se deseleccionó nada (y no se presionó shift), iniciar recuadro.
                if (!deselectedSomething) {
                    isSelecting = true;
                    controls.enabled = false; 
                    startPoint = { x: event.clientX, y: event.clientY };
                    endPoint = { x: event.clientX, y: event.clientY };
                    selectionBox.style.left = `${startPoint.x}px`;
                    selectionBox.style.top = `${startPoint.y}px`;
                    selectionBox.style.width = '0px';
                    selectionBox.style.height = '0px';
                    selectionBox.style.display = 'block';
                }
            } // Si se presionó Shift en el fondo, no hacer nada
        }
    }
});

renderer.domElement.addEventListener('mousemove', (event) => {
    if (isSelecting) {
        endPoint = { x: event.clientX, y: event.clientY };
        const width = Math.abs(endPoint.x - startPoint.x);
        const height = Math.abs(endPoint.y - startPoint.y);
        const left = Math.min(startPoint.x, endPoint.x);
        const top = Math.min(startPoint.y, endPoint.y);

        selectionBox.style.left = `${left}px`;
        selectionBox.style.top = `${top}px`;
        selectionBox.style.width = `${width}px`;
        selectionBox.style.height = `${height}px`;
    } else if (isDraggingPanel && draggedPanel) {
        // Calcular el desplazamiento del mouse
        const deltaX = event.clientX - dragStartPosition.x;
        const deltaY = event.clientY - dragStartPosition.y;
        
        // Calcular factor de escala con sensibilidad reducida
        const screenToWorldFactor = 0.005 * dragSensitivity * (camera.position.z / 5);
        
        // Calcular nueva posición
        let newX = dragStartPanelPosition.x + deltaX * screenToWorldFactor;
        let newY = dragStartPanelPosition.y - deltaY * screenToWorldFactor; // Y invertido
        
        // Obtener parámetros actuales del grid para snap to grid
        if (dragSnapToGrid) {
            const currentGridParams = getCurrentGridParams();
            if (currentGridParams) {
                const { cellSize, halfWidth, halfHeight } = currentGridParams;
                
                // Calcular la posición de celda más cercana
                // Primero convertir de coordenadas de mundo a índices de celda
                const cellX = Math.round((newX + halfWidth) / cellSize - 0.5);
                const cellY = Math.round((newY + halfHeight) / cellSize - 0.5);
                
                // Convertir de vuelta a coordenadas de mundo para snap
                const snappedX = -halfWidth + (cellX + 0.5) * cellSize;
                const snappedY = -halfHeight + (cellY + 0.5) * cellSize;
                
                // Aplicar un factor de atracción suave
                const snapStrength = 0.4; // 0 = sin snap, 1 = snap total
                newX = newX * (1 - snapStrength) + snappedX * snapStrength;
                newY = newY * (1 - snapStrength) + snappedY * snapStrength;
            }
        }
        
        // Actualizar la posición visual del panel
        draggedPanel.group.position.set(newX, newY, draggedPanel.group.position.z);
        
        // Actualizar el cursor
        renderer.domElement.style.cursor = 'move';
        
        // Desactivar los controles de OrbitControls mientras se arrastra
        controls.enabled = false;
    } else {
        // --- Lógica de Hover para TODO el panel (borde y relleno) --- 
        mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
        mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
        
        // Configurar raycaster con posición precisa
        raycaster.setFromCamera(mouse, camera);

        // Recopilar todos los objetos para hover (igual que en mousedown)
        const allHoverables = [];
        
        // Añadir todos los meshes de relleno
        const allFillMeshes = panels.map(p => p.fillMesh).filter(Boolean);
        allHoverables.push(...allFillMeshes);
        
        // Añadir también líneas de borde
        const allBorderLines = panels.flatMap(p => p.borderLines || []).filter(Boolean);
        allHoverables.push(...allBorderLines);
        
        // Ordenar por distancia
        const intersects = raycaster.intersectObjects(allHoverables, false)
            .sort((a, b) => a.distance - b.distance);

        let newHoveredPanelData = null;
        if (intersects.length > 0) {
            // El objeto intersectado es una línea o mesh, obtener panelData
            let currentObject = intersects[0].object;
            
            // Si es un fillMesh, podría tener referencia directa
            if (currentObject.userData && currentObject.userData.panelDataRef) {
                newHoveredPanelData = currentObject.userData.panelDataRef;
            } else {
                // Buscar hacia arriba en la jerarquía
                while (currentObject && !newHoveredPanelData) {
                    if (currentObject.userData && currentObject.userData.panelDataRef) {
                        newHoveredPanelData = currentObject.userData.panelDataRef;
                        break;
                    }
                    currentObject = currentObject.parent;
                }
            }
        }

        // Si el panel hovereado cambió
        if (newHoveredPanelData !== currentlyHoveredPanel) {
            // Quitar hover del anterior (si existe)
            if (currentlyHoveredPanel) {
                currentlyHoveredPanel.hovered = false;
                updatePanelColor(currentlyHoveredPanel);
            }
            // Poner hover en el nuevo (si existe)
            if (newHoveredPanelData) {
                newHoveredPanelData.hovered = true;
                updatePanelColor(newHoveredPanelData);
            }
            currentlyHoveredPanel = newHoveredPanelData;
        }
    }
});

renderer.domElement.addEventListener('mouseup', (event) => {
    // Cancelar temporizador de inicio de arrastre si existe
    if (dragStartTimer) {
        clearTimeout(dragStartTimer);
        dragStartTimer = null;
    }
    
    // Limpiar panel potencial para arrastrar
    potentialDragPanel = null;
    
    if (isSelecting && event.button === 0) {
        isSelecting = false;
        controls.enabled = true; // Rehabilitar controles
        selectionBox.style.display = 'none';

        // Obtener puntos 3D de inicio y fin
        const start3D = get3DPointOnGrid({clientX: startPoint.x, clientY: startPoint.y});
        const end3D = get3DPointOnGrid({clientX: endPoint.x, clientY: endPoint.y});

        // Crear panel basado en la selección
        if (start3D && end3D) {
           createPanelFromSelection(start3D, end3D);
        }
    } else if (isDraggingPanel && draggedPanel && event.button === 0) {
        // Finalizar arrastre
        isDraggingPanel = false;
        
        // Obtener parámetros actuales del grid
        const currentGridParams = getCurrentGridParams();
        if (!currentGridParams) {
            // Restaurar posición original si no podemos obtener los parámetros
            draggedPanel.group.position.set(
                dragStartPanelPosition.x, 
                dragStartPanelPosition.y, 
                draggedPanel.group.position.z
            );
            draggedPanel = null;
            controls.enabled = true;
            renderer.domElement.style.cursor = 'auto';
            return;
        }
        
        const { cellSize, halfWidth, halfHeight, cellsX, cellsY } = currentGridParams;
        
        // Calcular nuevos índices basados en la posición actual
        const groupX = draggedPanel.group.position.x;
        const groupY = draggedPanel.group.position.y;
        
        // Convertir posición a índices de celda
        const cellX = Math.round((groupX + halfWidth) / cellSize - 0.5);
        const cellY = Math.round((groupY + halfHeight) / cellSize - 0.5);
        
        // Calcular el desplazamiento en celdas
        const cellDeltaX = cellX - (dragStartCellIndices.minX + (dragStartCellIndices.maxX - dragStartCellIndices.minX) / 2);
        const cellDeltaY = cellY - (dragStartCellIndices.minY + (dragStartCellIndices.maxY - dragStartCellIndices.minY) / 2);
        
        // Comprobar si el movimiento es válido
        if (cellDeltaX !== 0 || cellDeltaY !== 0) {
            const newMinX = dragStartCellIndices.minX + Math.round(cellDeltaX);
            const newMaxX = dragStartCellIndices.maxX + Math.round(cellDeltaX);
            const newMinY = dragStartCellIndices.minY + Math.round(cellDeltaY);
            const newMaxY = dragStartCellIndices.maxY + Math.round(cellDeltaY);
            
            // Verificar límites del grid
            if (newMinX < 0 || newMaxX >= cellsX || newMinY < 0 || newMaxY >= cellsY) {
                // Movimiento fuera de límites, restaurar posición
                draggedPanel.group.position.set(
                    dragStartPanelPosition.x, 
                    dragStartPanelPosition.y, 
                    draggedPanel.group.position.z
                );
            } else {
                // Verificar colisiones con otros paneles
                let hasCollision = false;
                
                // Comprobar colisión con todos los paneles excepto el arrastrado
                for (const panel of panels) {
                    if (panel === draggedPanel) continue;
                    
                    const eMinX = panel.minCellIndex.x;
                    const eMaxX = panel.maxCellIndex.x;
                    const eMinY = panel.minCellIndex.y;
                    const eMaxY = panel.maxCellIndex.y;
                    
                    // Comprobar si los rectángulos de índices (con margen de 1 celda) se solapan
                    const conflictX = !(newMaxX < eMinX - 1 || newMinX > eMaxX + 1);
                    const conflictY = !(newMaxY < eMinY - 1 || newMinY > eMaxY + 1);
                    
                    if (conflictX && conflictY) {
                        hasCollision = true;
                        break;
                    }
                }
                
                if (hasCollision) {
                    // Colisión detectada, restaurar posición
                    draggedPanel.group.position.set(
                        dragStartPanelPosition.x, 
                        dragStartPanelPosition.y, 
                        draggedPanel.group.position.z
                    );
                } else {
                    // Movimiento válido, actualizar índices
                    draggedPanel.minCellIndex.x = newMinX;
                    draggedPanel.minCellIndex.y = newMinY;
                    draggedPanel.maxCellIndex.x = newMaxX;
                    draggedPanel.maxCellIndex.y = newMaxY;
                    
                    // Actualizar geometría según nuevos índices
                    updatePanelGeometryAndPosition(draggedPanel, currentGridParams);
                    
                    // Recrear la etiqueta con el número de orden
                    createPanelOrderLabel(draggedPanel);
                    
                    // Flash del panel para indicar el cambio de posición
                    draggedPanel.flashProgress = 0;
                    draggedPanel.shouldFlash = true;
                    panelsFlashing.add(draggedPanel);
                }
            }
        } else {
            // Sin cambio de celda, restaurar posición exacta
            draggedPanel.group.position.set(
                dragStartPanelPosition.x, 
                dragStartPanelPosition.y, 
                draggedPanel.group.position.z
            );
        }
        
        // Limpiar
        draggedPanel = null;
        controls.enabled = true;
        renderer.domElement.style.cursor = 'auto';
    } else if (event.button === 0) {
        // Si se soltó el botón sin iniciar arrastre ni selección de área,
        // asegurarse de reactivar los controles
        controls.enabled = true;
        renderer.domElement.style.cursor = 'auto';
    }
});

// Añadir evento para cancelar arrastre y su temporizador al salir del canvas
renderer.domElement.addEventListener('mouseleave', () => {
    // Cancelar temporizador de inicio de arrastre
    if (dragStartTimer) {
        clearTimeout(dragStartTimer);
        dragStartTimer = null;
        potentialDragPanel = null;
    }
    
    if (isDraggingPanel && draggedPanel) {
        // Restaurar posición original
        draggedPanel.group.position.set(
            dragStartPanelPosition.x, 
            dragStartPanelPosition.y, 
            draggedPanel.group.position.z
        );
        
        // Limpiar estado
        isDraggingPanel = false;
        draggedPanel = null;
        controls.enabled = true;
        renderer.domElement.style.cursor = 'auto';
    }
});

// --- Funciones de Configuración --- 

function getSerializableConfig() {
    // Obtener configuración actual de la cuadrícula
    const currentGridParams = getCurrentGridParams();
    if (!currentGridParams) return null;
    
    // Serializar los paneles (solo las propiedades necesarias)
    const serializedPanels = panels.map((panel, index) => {
        return {
            id: `0_${panel.orderNumber}`, // Estado actual es 0, luego número de panel
            minCellIndex: { ...panel.minCellIndex },
            maxCellIndex: { ...panel.maxCellIndex },
            orderNumber: panel.orderNumber,
            showOrderNumber: panel.showOrderNumber
        };
    });
    
    // Devolver objeto de configuración completo
    return {
        id: `config_${new Date().getTime()}`,
        grid: {
            cellSize: currentGridParams.cellSize,
            cellsX: currentGridParams.cellsX,
            cellsY: currentGridParams.cellsY
        },
        panels: serializedPanels,
        cameraPosition: {
            x: camera.position.x,
            y: camera.position.y,
            z: camera.position.z
        },
        cameraZoom: camera.zoom,
        date: new Date().toISOString()
    };
}

function saveConfiguration() {
    try {
        const config = getSerializableConfig();
        const configString = JSON.stringify(config);
        localStorage.setItem('gridConfig', configString);
        console.log('Configuración guardada en localStorage.');
    } catch (error) {
        console.error('Error al guardar configuración:', error);
    }
}

function loadConfiguration() {
    try {
        const configString = localStorage.getItem('gridConfig');
        if (!configString) {
            console.log('No hay configuración guardada en localStorage.');
            return;
        }

        const config = JSON.parse(configString);

        // 1. Limpiar paneles actuales
        panels.forEach(panel => {
            if(panel.group) scene.remove(panel.group); 
            // No necesitamos limpiar geometría aquí, se hará al recrear
        });
        panels.length = 0;
        currentlyHoveredPanel = null;
        console.log('Paneles antiguos limpiados.');

        // 2. Actualizar la división del grid (esto llamará a updateGrid)
        // updateGrid se encargará de recrear el grid visual
        if (typeof config.grid.cellSize === 'number' && config.grid.cellSize !== currentDivisions) {
             console.log(`Cargando división: ${config.grid.cellSize}`);
             updateGrid(config.grid.cellSize); // Esto actualiza currentDivisions internamente
        } else {
            // Si la división no cambió, necesitamos forzar la actualización visual
            // de los paneles vacíos sobre el grid actual
            updateGrid(currentDivisions);
        }
        
        // 3. Recrear paneles desde los datos cargados
        // Esperar un frame para asegurar que el grid esté actualizado por updateGrid
        requestAnimationFrame(() => {
             const currentGridParams = getCurrentGridParams();
             if (!currentGridParams) {
                 console.error("No se pudieron obtener los parámetros del grid después de cargar.");
                 return;
             }
             console.log(`Recreando ${config.panels.length} paneles...`);
             config.panels.forEach(panelInfo => {
                 const panelData = {
                     group: null,
                     minCellIndex: { x: panelInfo.minCellIndex.x, y: panelInfo.minCellIndex.y },
                     maxCellIndex: { x: panelInfo.maxCellIndex.x, y: panelInfo.maxCellIndex.y }
                     // selected/hovered se inicializan en updatePanelGeometryAndPosition
                 };
                 updatePanelGeometryAndPosition(panelData, currentGridParams);
                 if(panelData.group) {
                     scene.add(panelData.group);
                     panels.push(panelData);
                 }
             });
             console.log('Paneles recreados.');
        });

        console.log('Configuración cargada desde localStorage.');

    } catch (error) {
        console.error('Error al cargar configuración:', error);
    }
}

// Función para descargar la configuración actual como archivo JSON
function downloadConfiguration() {
    const configData = getSerializableConfig();
    if (!configData) return;
    
    // Crear objeto con todos los estados guardados
    const allStates = {
        currentState: configData,
        savedStates: []
    };
    
    // Procesar los 10 slots de estados guardados
    for (let i = 0; i < 10; i++) {
        const state = savedScreenStates[i];
        if (state) {
            // Si es un string (guardado como JSON), convertirlo a objeto
            const stateObj = typeof state === 'string' ? JSON.parse(state) : state;
            
            // Asegurarse de que los paneles tienen IDs y números de orden
            if (stateObj.panels) {
                stateObj.panels = stateObj.panels.map((panel, idx) => {
                    return {
                        id: `${i+1}_${panel.orderNumber || idx+1}`, // layout_panel
                        minCellIndex: panel.minCellIndex,
                        maxCellIndex: panel.maxCellIndex,
                        orderNumber: panel.orderNumber || idx + 1,
                        showOrderNumber: panel.showOrderNumber !== undefined ? panel.showOrderNumber : true,
                        selected: panel.selected || false
                    };
                });
            }
            
            // Añadir ID del estado si no lo tiene
            stateObj.id = stateObj.id || `state_${i+1}_${new Date().getTime()}`;
            
            // Añadir el estado al arreglo
            allStates.savedStates.push(stateObj);
        } else {
            // Si no hay estado guardado, añadir un placeholder vacío
            allStates.savedStates.push(null);
        }
    }
    
    const jsonData = JSON.stringify(allStates, null, 2);
    const blob = new Blob([jsonData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `bioPrint_config_${new Date().toISOString().replace(/[:.]/g, "-")}.json`;
    document.body.appendChild(a);
    a.click();
    
    setTimeout(() => {
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }, 100);
}

// Función para descargar todos los estados guardados como un solo archivo JSON
function downloadAllSavedStates() {
    if (savedScreenStates.length === 0) {
        alert("No hay estados guardados para descargar");
        return;
    }
    
    // Crear objeto con todos los estados guardados
    const allSavedData = {
        currentState: getSerializableConfig(),
        savedStates: savedScreenStates.map(state => JSON.parse(state)),
        exportDate: new Date().toISOString()
    };
    
    const jsonData = JSON.stringify(allSavedData, null, 2);
    const blob = new Blob([jsonData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `bioPrint_all_states_${new Date().toISOString().replace(/[:.]/g, "-")}.json`;
    document.body.appendChild(a);
    a.click();
    
    setTimeout(() => {
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }, 100);
}

// Función para cargar configuración desde un archivo JSON
function loadConfigurationFromFile(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const data = JSON.parse(e.target.result);
            
            // Comprobar si es un archivo con múltiples estados
            if (data.savedStates && Array.isArray(data.savedStates)) {
                // Cargar el estado actual
                if (data.currentState) {
                    applyConfigurationFromData(data.currentState);
                }
                
                // Guardar todos los estados en savedScreenStates
                savedScreenStates = data.savedStates.map(state => JSON.stringify(state));
                
                // Actualizar la interfaz de usuario con los estados cargados
                updateScreenStatesList();
                
                console.log(`Cargados ${data.savedStates.length} estados guardados`);
            } else {
                // Es un archivo de configuración normal (un solo estado)
                applyConfigurationFromData(data);
            }
        } catch (error) {
            console.error("Error al cargar el archivo:", error);
            alert("El archivo seleccionado no tiene un formato válido");
        }
    };
    
    reader.readAsText(file);
}

// --- Event Listeners para Botones --- 
document.getElementById('save-config-btn').addEventListener('click', saveConfiguration);
document.getElementById('load-config-btn').addEventListener('click', loadConfiguration);
document.getElementById('download-config-btn').addEventListener('click', downloadConfiguration);
document.getElementById('clear-layout-btn').addEventListener('click', clearAllPanels);
document.getElementById('toggle-numbers-btn').addEventListener('click', togglePanelNumbers);

// --- Carga Inicial --- 
// Intentar cargar la configuración guardada al iniciar
loadConfiguration(); 

// Función para animar el grid
function animateGrid() {
    if (!gridAnimationInProgress || !currentGrid) return;
    
    console.log("Animando grid, paso:", gridAnimationStep, "progreso:", gridAnimationProgress);
    
    // Obtener grupos desde userData
    const borderGroup = currentGrid.userData.borderGroup;
    const linesGroup = currentGrid.userData.linesGroup;
    
    // Paso 0: Escalar el grid desde pequeño a normal
    if (gridAnimationStep === 0) {
        gridAnimationProgress += 0.02;
        
        // Escalar el grid
        const newScale = THREE.MathUtils.lerp(0.01, gridAnimationProps.targetScale, gridAnimationProgress);
        currentGrid.scale.set(newScale, newScale, newScale);
        
        // Animar opacidad del borde
        const borderOpacity = THREE.MathUtils.lerp(0, gridAnimationProps.borderOpacity, gridAnimationProgress);
        borderGroup.children.forEach(line => {
            line.material.opacity = borderOpacity;
        });
        
        // Cuando termina la animación de escala
        if (gridAnimationProgress >= 1) {
            gridAnimationProgress = 0;
            gridAnimationStep = 1;
            console.log("Paso 1 de animación completado");
        }
    }
    // Paso 1: Mostrar subdivisiones
    else if (gridAnimationStep === 1) {
        gridAnimationProgress += 0.03;
        
        // Aumentar la opacidad de las líneas internas gradualmente
        const linesOpacity = THREE.MathUtils.lerp(0, 1, gridAnimationProgress);
        linesGroup.children.forEach(line => {
            line.material.opacity = linesOpacity;
        });
        
        // Pasar al siguiente paso cuando termine este
        if (gridAnimationProgress >= 1) {
            gridAnimationProgress = 0;
            gridAnimationStep = 2;
            console.log("Paso 2 de animación completado");
        }
    }
    // Paso 2: Flash (destello)
    else if (gridAnimationStep === 2) {
        gridAnimationProgress += 0.1;
        
        // Función senoidal para generar un destello (aumenta y disminuye)
        const flash = Math.sin(gridAnimationProgress * Math.PI);
        
        // Aplicar el destello a todo el grid
        const flashColor = new THREE.Color(0xffffff);
        const baseColor = new THREE.Color(0x888888);
        
        // Interpolar entre el color base y el color del flash
        const resultColor = new THREE.Color().lerpColors(baseColor, flashColor, flash * 0.7);
        
        // Aplicar a todas las líneas
        linesGroup.children.forEach(line => {
            line.material.color = resultColor.clone();
        });
        
        borderGroup.children.forEach(line => {
            line.material.color = resultColor.clone();
        });
        
        // Reset y siguiente flash cuando termine un ciclo completo
        if (gridAnimationProgress >= 1) {
            gridAnimationProgress = 0;
            gridFlashCount++;
            
            // Terminar después de 2 flashes
            if (gridFlashCount >= 2) {
                // Restaurar colores originales
                const originalColor = new THREE.Color(0x888888);
                linesGroup.children.forEach(line => {
                    line.material.color = originalColor.clone();
                });
                borderGroup.children.forEach(line => {
                    line.material.color = originalColor.clone();
                });
                
                // Terminar la animación
                gridAnimationInProgress = false;
                isFirstGridCreation = false;
                console.log("Animación del grid completada");
                
                // Guardar configuración inicial de la cámara ahora que ya tenemos el grid
                if (!initialCameraState.position) {
                    initialCameraState.position = camera.position.clone();
                    initialCameraState.zoom = camera.zoom;
                    initialCameraState.distance = camera.position.distanceTo(new THREE.Vector3(0, 0, 0));
                    console.log("Guardada configuración inicial de cámara");
                }
            }
        }
    }
}


// Función auxiliar para actualizar opacidad
function updateMaterialOpacity(object, callback) {
    if (object.material) {
        callback(object.material);
    }
    
    if (object.children) {
        object.children.forEach(child => {
            updateMaterialOpacity(child, callback);
        });
    }
}

// Función para actualizar paneles después de la animación
function updatePanelsAfterGridAnimation() {
    const currentGridParams = getCurrentGridParams();
    if (!currentGridParams) return;
    
    // Guardar propiedades para animar desde el estado actual
    panels.forEach(panelData => {
        // Guardar datos actuales para animación
        if (panelData.group) {
            // Guardar posición actual
            panelData.oldPosition = {
                x: panelData.group.position.x,
                y: panelData.group.position.y,
                z: panelData.group.position.z
            };
            
            // Guardar geometría actual para borde y relleno
            panelData.oldGeometry = {
                borderPoints: [], // Se llenará si existe el borde
                fillShape: null // Se llenará si existe el relleno
            };
            
            // Intentar guardar puntos del borde
            if (panelData.borderLines && panelData.borderLines[0]) {
                const borderLine = panelData.borderLines[0];
                const positions = borderLine.geometry.attributes.position;
                for (let i = 0; i < positions.count; i++) {
                    panelData.oldGeometry.borderPoints.push(
                        new THREE.Vector3(
                            positions.getX(i),
                            positions.getY(i),
                            positions.getZ(i)
                        )
                    );
                }
            }
            
            // Guardar forma del relleno (simplificado, solo guardaremos el tamaño)
            if (panelData.fillMesh) {
                panelData.oldGeometry.fillSize = {
                    width: panelData.fillMesh.geometry.parameters ? 
                           panelData.fillMesh.geometry.parameters.width : null,
                    height: panelData.fillMesh.geometry.parameters ? 
                            panelData.fillMesh.geometry.parameters.height : null
                };
            }
        }
        
        const wasSelected = panelData.selected;
        const wasHovered = (panelData === currentlyHoveredPanel);
        
        // Calcular PERO NO APLICAR los nuevos datos del panel
        const { cellSize, halfWidth, halfHeight } = currentGridParams;
        const { minCellIndex, maxCellIndex } = panelData;
        
        const panelCellsX = maxCellIndex.x - minCellIndex.x + 1;
        const panelCellsY = maxCellIndex.y - minCellIndex.y + 1;
        
        const panelWidth = panelCellsX * cellSize;
        const panelHeight = panelCellsY * cellSize;
        
        // Calcular nuevo centro basado en índices y tamaño de celda actual
        const newPanelCenterX = -halfWidth + (minCellIndex.x + panelCellsX / 2) * cellSize;
        const newPanelCenterY = -halfHeight + (minCellIndex.y + panelCellsY / 2) * cellSize;
        
        const panelHalfWidth = panelWidth / 2;
        const panelHalfHeight = panelHeight / 2;
        const bevelSize = cellSize * 0.5;
        
        // Guardar datos objetivo de animación
        panelData.animTarget = {
            position: { x: newPanelCenterX, y: newPanelCenterY, z: 0.01 },
            size: { width: panelWidth, height: panelHeight, 
                   halfWidth: panelHalfWidth, halfHeight: panelHalfHeight,
                   bevelSize: bevelSize }
        };
        
        // Preparar para animación en lugar de actualizar inmediatamente
        panelData.resizeProgress = 0;
        panelData.isResizing = true;
        panelsResizing.add(panelData);
        
        // Restaurar estados
        panelData.selected = wasSelected;
        panelData.hovered = wasHovered;
    });
}

// Función para animar el cambio de forma de los paneles
function animateResizingPanels() {
    const panelsToFinalize = [];
    
    panelsResizing.forEach(panelData => {
        if (!panelData.isResizing || !panelData.group) {
            panelsToFinalize.push(panelData);
            return;
        }
        
        // Incrementar progreso (velocidad de animación)
        panelData.resizeProgress += 0.05;
        const progress = Math.min(1, panelData.resizeProgress);
        
        // Aplicar función de suavizado para que la animación sea más natural
        const easedProgress = 1 - Math.pow(1 - progress, 3); // Cubic ease out
        
        // 1. Animar la posición del grupo
        if (panelData.oldPosition && panelData.animTarget.position) {
            panelData.group.position.x = THREE.MathUtils.lerp(
                panelData.oldPosition.x, 
                panelData.animTarget.position.x, 
                easedProgress
            );
            panelData.group.position.y = THREE.MathUtils.lerp(
                panelData.oldPosition.y, 
                panelData.animTarget.position.y, 
                easedProgress
            );
        }
        
        // 2. Animar la forma
        const size = panelData.animTarget.size;
        
        // 2.1 Animar el borde (crear nuevos puntos interpolados)
        if (panelData.borderLines && panelData.borderLines[0] && panelData.oldGeometry.borderPoints.length > 0) {
            const oldPoints = panelData.oldGeometry.borderPoints;
            
            // Calcular puntos del borde objetivo
            const targetPoints = [];
            // Izquierdo
            targetPoints.push(new THREE.Vector3(-size.halfWidth, -size.halfHeight + size.bevelSize, 0));
            targetPoints.push(new THREE.Vector3(-size.halfWidth, size.halfHeight - size.bevelSize, 0));
            // Sup Izq (bisel)
            targetPoints.push(new THREE.Vector3(-size.halfWidth + size.bevelSize, size.halfHeight, 0));
            // Superior
            targetPoints.push(new THREE.Vector3(size.halfWidth - size.bevelSize, size.halfHeight, 0));
            // Sup Der (bisel)
            targetPoints.push(new THREE.Vector3(size.halfWidth, size.halfHeight - size.bevelSize, 0));
            // Derecho
            targetPoints.push(new THREE.Vector3(size.halfWidth, -size.halfHeight + size.bevelSize, 0));
            // Inf Der (bisel)
            targetPoints.push(new THREE.Vector3(size.halfWidth - size.bevelSize, -size.halfHeight, 0));
            // Inferior
            targetPoints.push(new THREE.Vector3(-size.halfWidth + size.bevelSize, -size.halfHeight, 0));
            // Inf Izq (bisel) y cerrar
            targetPoints.push(new THREE.Vector3(-size.halfWidth, -size.halfHeight + size.bevelSize, 0));
            
            // Asegurarse de que tenemos la misma cantidad de puntos
            const pointCount = Math.min(oldPoints.length, targetPoints.length);
            
            // Crear puntos interpolados
            const interpolatedPoints = [];
            for (let i = 0; i < pointCount; i++) {
                const interpolatedPoint = new THREE.Vector3(
                    THREE.MathUtils.lerp(oldPoints[i].x, targetPoints[i].x, easedProgress),
                    THREE.MathUtils.lerp(oldPoints[i].y, targetPoints[i].y, easedProgress),
                    0
                );
                interpolatedPoints.push(interpolatedPoint);
            }
            
            // Actualizar geometría del borde
            panelData.borderLines[0].geometry.dispose();
            panelData.borderLines[0].geometry = new THREE.BufferGeometry().setFromPoints(interpolatedPoints);
            panelData.borderLines[0].geometry.computeBoundingSphere();
        }
        
        // 2.2 Animar el relleno (Shape)
        if (panelData.fillMesh && panelData.oldGeometry.fillSize) {
            // Crear una nueva forma interpolada
            const shape = new THREE.Shape();
            
            // Calcular dimensiones intermedias
            const oldWidth = panelData.oldGeometry.fillSize.width || size.width;
            const oldHeight = panelData.oldGeometry.fillSize.height || size.height;
            
            const currentWidth = THREE.MathUtils.lerp(oldWidth, size.width, easedProgress);
            const currentHeight = THREE.MathUtils.lerp(oldHeight, size.height, easedProgress);
            
            const currentHalfWidth = currentWidth / 2;
            const currentHalfHeight = currentHeight / 2;
            
            // Interpolar también el tamaño del bisel
            const oldBevelSize = panelData.oldGeometry.fillSize.bevelSize || size.bevelSize;
            const currentBevelSize = THREE.MathUtils.lerp(oldBevelSize, size.bevelSize, easedProgress);
            
            // Recrear la forma con dimensiones interpoladas
            // Empezar en esquina inf izq (después del bisel)
            shape.moveTo(-currentHalfWidth + currentBevelSize, -currentHalfHeight);
            // Lado inferior
            shape.lineTo(currentHalfWidth - currentBevelSize, -currentHalfHeight);
            // Esquina inf der (bisel)
            shape.lineTo(currentHalfWidth, -currentHalfHeight + currentBevelSize);
            // Lado derecho
            shape.lineTo(currentHalfWidth, currentHalfHeight - currentBevelSize);
            // Esquina sup der (bisel)
            shape.lineTo(currentHalfWidth - currentBevelSize, currentHalfHeight);
            // Lado superior
            shape.lineTo(-currentHalfWidth + currentBevelSize, currentHalfHeight);
            // Esquina sup izq (bisel)
            shape.lineTo(-currentHalfWidth, currentHalfHeight - currentBevelSize);
            // Lado izquierdo
            shape.lineTo(-currentHalfWidth, -currentHalfHeight + currentBevelSize);
            // Cerrar (vuelve al punto inicial)
            shape.closePath();
            
            // Actualizar geometría del relleno
            panelData.fillMesh.geometry.dispose();
            panelData.fillMesh.geometry = new THREE.ShapeGeometry(shape);
        }
        
        // Finalizar animación cuando completemos
        if (progress >= 1) {
            panelData.isResizing = false;
            panelsToFinalize.push(panelData);
            
            // Iniciar flash al completar el cambio de forma
            panelData.flashProgress = 0;
            panelData.shouldFlash = true;
            panelsFlashing.add(panelData);
        }
    });
    
    // Limpiar paneles que terminaron su animación
    panelsToFinalize.forEach(panel => {
        panelsResizing.delete(panel);
    });
}

// Función para animar el flash de los paneles
function animateFlashingPanels() {
    const panelsToRemove = [];

    // Recorrer todos los paneles en animación
    panelsFlashing.forEach(panelData => {
        if (!panelData.shouldFlash) {
            panelsToRemove.push(panelData);
            return;
        }

        // Incrementar progreso de animación
        panelData.flashProgress += 0.05;
        
        // Crear efecto de flash basado en función senoidal
        const flashIntensity = Math.sin(panelData.flashProgress * Math.PI * 2);
        const positiveFlash = Math.max(0, flashIntensity); // Solo valores positivos para flash
        
        // Colores para flash (blanco brillante)
        const baseColor = new THREE.Color(
            panelData.selected ? 0xffffff : 
            panelData.hovered ? 0xcccccc : 0xaaaaaa
        );
        const flashColor = new THREE.Color(0xffffff);
        
        // Aplicar flash a materiales temporales
        if (panelData && panelData.group) {
            panelData.group.children.forEach(child => {
                if (child instanceof THREE.Line && child.material) {
                    // Interpolar entre el color original y blanco
                    const color = new THREE.Color().lerpColors(
                        baseColor, 
                        flashColor, 
                        positiveFlash * 0.7
                    );
                    child.material = child.material.clone();
                    child.material.color = color;
                }
                else if (child === panelData.fillMesh && child.material) {
                    // Flash también en el relleno (cambiando color y opacidad)
                    const color = new THREE.Color().lerpColors(
                        baseColor, 
                        flashColor, 
                        positiveFlash * 0.7
                    );
                    child.material = child.material.clone();
                    child.material.color = color;
                    
                    // Aumentar opacidad ligeramente durante el flash
                    const baseOpacity = panelData.selected ? 0.4 : (panelData.hovered ? 0.3 : 0.2);
                    child.material.opacity = baseOpacity + (positiveFlash * 0.3);
                }
            });
        }
        
        // Finalizar animación después de 2 ciclos completos
        if (panelData.flashProgress >= 2) {
            panelData.shouldFlash = false;
            panelsToRemove.push(panelData);
            
            // Restaurar materiales originales
            updatePanelColor(panelData);
        }
    });
    
    // Limpiar paneles que ya no están en animación
    panelsToRemove.forEach(panel => {
        panelsFlashing.delete(panel);
    });
}

// Función para centrar el grid en la cámara con una animación suave
function centerGridInCamera() {
    // Guardar la posición inicial de la cámara y los controles
    const startPosition = camera.position.clone();
    const startTarget = controls.target.clone();
    
    // Usar la posición inicial de la cámara para el zoom
    const targetTarget = new THREE.Vector3(0, 0, 0);
    
    // Calcular la posición objetivo manteniendo la distancia inicial
    // Usamos la misma distancia que se configuró al iniciar la aplicación
    const targetPosition = new THREE.Vector3(0, 0, initialCameraState.distance);
    
    // Duración de la animación en milisegundos
    const duration = 800;
    const startTime = performance.now();
    
    // Animación personalizada para el centrado
    function animateCentering(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        // Función de suavizado para movimiento natural
        const smoothProgress = 1 - Math.pow(1 - progress, 3); // Cubic ease out
        
        // Interpolar posición de la cámara
        camera.position.lerpVectors(startPosition, targetPosition, smoothProgress);
        
        // Interpolar objetivo de los controles
        controls.target.lerpVectors(startTarget, targetTarget, smoothProgress);
        
        // Actualizar controles y cámara
        controls.update();
        
        // Continuar la animación si no ha terminado
        if (progress < 1) {
            requestAnimationFrame(animateCentering);
        } else {
            // Flash del grid al terminar el centrado (efecto visual de confirmación)
            if (currentGrid) {
                gridAnimationInProgress = true;
                gridAnimationStep = 2; // Solo paso de flash
                gridAnimationProgress = 0;
                gridFlashCount = 0;
            }
        }
    }
    
    // Iniciar la animación
    requestAnimationFrame(animateCentering);
}

// Función para guardar el estado actual de la pantalla
function saveScreenState(index) {
    if (index < 0 || index > 9) return; // Validar índice
    
    // Recopilar datos de todos los paneles actuales
    const currentPanels = panels.map((panel, panelIndex) => ({
        id: `${index+1}_${panel.orderNumber}`, // layout_panel
        minCellIndex: { x: panel.minCellIndex.x, y: panel.minCellIndex.y },
        maxCellIndex: { x: panel.maxCellIndex.x, y: panel.maxCellIndex.y },
        orderNumber: panel.orderNumber,
        showOrderNumber: panel.showOrderNumber,
        selected: panel.selected
    }));
    
    // Guardar datos de cámara y grid
    const screenState = {
        id: `state_${index+1}_${new Date().getTime()}`,
        cameraPosition: camera.position.clone(),
        cameraTarget: controls.target.clone(),
        gridDivisions: currentDivisions,
        panels: currentPanels,
        timestamp: new Date().toLocaleTimeString(),
        date: new Date().toISOString()
    };
    
    // Guardar en el slot correspondiente
    savedScreenStates[index] = JSON.stringify(screenState);
    lastSavedStateIndex = index;
    
    // Actualizar UI
    updateStateButtons();
    
    // Flash de confirmación visual
    gridAnimationInProgress = true;
    gridAnimationStep = 2; // Solo paso de flash
    gridAnimationProgress = 0;
    gridFlashCount = 0;
    
    console.log(`Estado de pantalla guardado en slot ${index + 1}`);
}

// Función para cargar un estado guardado
function loadScreenState(index) {
    if (index < 0 || index > 9 || !savedScreenStates[index]) {
        console.log(`No hay estado guardado en slot ${index + 1}`);
        return; // No hay estado guardado en este slot
    }
    
    // Convertir de JSON string a objeto si es necesario
    const state = typeof savedScreenStates[index] === 'string' 
                  ? JSON.parse(savedScreenStates[index]) 
                  : savedScreenStates[index];
    
    // Aplicar configuración de cámara
    camera.position.copy(state.cameraPosition);
    controls.target.copy(state.cameraTarget);
    controls.update();
    
    // Aplicar división de grid
    if (state.gridDivisions !== currentDivisions) {
        updateGrid(state.gridDivisions);
    }
    
    // Limpiar todos los paneles actuales
    panels.forEach(panel => {
        if(panel.group) {
            scene.remove(panel.group);
            // Limpiar geometrías de los hijos (líneas)
            while(panel.group.children.length > 0){
                const child = panel.group.children[0]; 
                panel.group.remove(child);
                if (child.geometry) child.geometry.dispose();
            }
        }
    });
    panels.length = 0;
    currentlyHoveredPanel = null;
    
    // Recrear los paneles guardados
    const currentGridParams = getCurrentGridParams();
    if (currentGridParams) {
        state.panels.forEach(panelData => {
            const newPanelData = {
                id: panelData.id,
                group: null,
                minCellIndex: { x: panelData.minCellIndex.x, y: panelData.minCellIndex.y },
                maxCellIndex: { x: panelData.maxCellIndex.x, y: panelData.maxCellIndex.y },
                orderNumber: panelData.orderNumber,
                showOrderNumber: panelData.showOrderNumber !== undefined ? panelData.showOrderNumber : true
            };
            
            updatePanelGeometryAndPosition(newPanelData, currentGridParams);
            
            if (newPanelData.group) {
                scene.add(newPanelData.group);
                panels.push(newPanelData);
                
                // Crear etiqueta con número de orden
                createPanelOrderLabel(newPanelData);
                
                // Aplicar selección si estaba seleccionado
                if (panelData.selected) {
                    newPanelData.selected = true;
                    updatePanelColor(newPanelData);
                }
            }
        });
    }
    
    // Flash de confirmación visual
    gridAnimationInProgress = true;
    gridAnimationStep = 2; // Solo paso de flash
    gridAnimationProgress = 0;
    gridFlashCount = 0;
    
    console.log(`Estado de pantalla cargado desde slot ${index + 1} (guardado: ${state.timestamp})`);
}

// Función para actualizar la interfaz de botones de estado
function updateStateButtons() {
    savedScreenStates.forEach((state, index) => {
        const button = document.querySelector(`.state-button[data-index="${index}"]`);
        if (!button) return;
        
        // Limpiar cualquier indicador previo
        const existingIndicator = button.querySelector('.state-indicator');
        if (existingIndicator) {
            button.removeChild(existingIndicator);
        }
        
        if (state) {
            // Crear indicador para estados guardados
            const indicator = document.createElement('div');
            indicator.classList.add('state-indicator');
            indicator.style.position = 'absolute';
            indicator.style.top = '2px';
            indicator.style.right = '2px';
            indicator.style.width = '6px';
            indicator.style.height = '6px';
            indicator.style.borderRadius = '50%';
            indicator.style.backgroundColor = '#4CAF50'; // Verde
            
            button.appendChild(indicator);
            
            // Añadir tooltip con info del estado
            button.title = `Estado ${index + 1}: ${state.gridDivisions} divisiones, ${state.panels.length} paneles\nGuardado: ${state.timestamp}`;
        } else {
            button.title = `Estado ${index + 1}: Vacío`;
        }
    });
}

// Función para crear la interfaz de usuario de botones
function createUIControls() {
    // Crear contenedor principal para controles
    const controlsContainer = document.createElement('div');
    controlsContainer.id = 'ui-controls';
    controlsContainer.style.position = 'absolute';
    controlsContainer.style.bottom = '20px';
    controlsContainer.style.left = '50%';
    controlsContainer.style.transform = 'translateX(-50%)';
    controlsContainer.style.display = 'flex';
    controlsContainer.style.flexDirection = 'column';
    controlsContainer.style.alignItems = 'center';
    controlsContainer.style.backgroundColor = 'rgba(40, 40, 40, 0.7)';
    controlsContainer.style.padding = '10px';
    controlsContainer.style.borderRadius = '8px';
    controlsContainer.style.zIndex = '1000';
    controlsContainer.style.fontFamily = 'Arial, sans-serif';
    
    // Crear contenedor para botones de estado
    const stateButtonsContainer = document.createElement('div');
    stateButtonsContainer.style.display = 'flex';
    stateButtonsContainer.style.flexWrap = 'wrap';
    stateButtonsContainer.style.justifyContent = 'center';
    stateButtonsContainer.style.marginBottom = '10px';
    stateButtonsContainer.style.gap = '5px';
    
    // Crear botones de estado (1-10)
    for (let i = 0; i < 10; i++) {
        const stateButton = document.createElement('div');
        stateButton.classList.add('state-button');
        stateButton.dataset.index = i;
        stateButton.textContent = (i + 1).toString(); // Mostrar 1-10 en lugar de 0-9
        
        // Estilos para botones de estado
        stateButton.style.width = '30px';
        stateButton.style.height = '30px';
        stateButton.style.backgroundColor = '#444';
        stateButton.style.color = '#fff';
        stateButton.style.borderRadius = '4px';
        stateButton.style.display = 'flex';
        stateButton.style.justifyContent = 'center';
        stateButton.style.alignItems = 'center';
        stateButton.style.cursor = 'pointer';
        stateButton.style.userSelect = 'none';
        stateButton.style.fontSize = '14px';
        stateButton.style.position = 'relative'; // Para el indicador
        
        // Eventos para botones de estado
        stateButton.addEventListener('click', (event) => {
            const index = parseInt(event.target.dataset.index);
            
            if (event.shiftKey) {
                // Shift + Click: Guardar estado
                saveScreenState(index);
            } else {
                // Click normal: Cargar estado
                loadScreenState(index);
            }
        });
        
        stateButton.addEventListener('mouseover', () => {
            stateButton.style.backgroundColor = '#555';
        });
        
        stateButton.addEventListener('mouseout', () => {
            stateButton.style.backgroundColor = '#444';
        });
        
        stateButtonsContainer.appendChild(stateButton);
    }
    
    // Añadir leyenda para los botones de estado
    const stateButtonsLegend = document.createElement('div');
    stateButtonsLegend.style.fontSize = '12px';
    stateButtonsLegend.style.color = '#ccc';
    stateButtonsLegend.style.marginBottom = '10px';
    stateButtonsLegend.style.textAlign = 'center';
    stateButtonsLegend.innerHTML = 'Click: Cargar estado | Shift+Click: Guardar estado';
    
    // Crear botón de Clear (limpiar paneles)
    const clearButton = document.createElement('div');
    clearButton.id = 'clear-button';
    clearButton.textContent = 'Clear Panels';
    
    // Estilos para botón de Clear
    clearButton.style.padding = '8px 16px';
    clearButton.style.backgroundColor = '#8B0000'; // Rojo oscuro
    clearButton.style.color = '#fff';
    clearButton.style.borderRadius = '4px';
    clearButton.style.cursor = 'pointer';
    clearButton.style.userSelect = 'none';
    clearButton.style.fontSize = '14px';
    clearButton.style.marginTop = '5px';
    
    // Eventos para botón de Clear
    clearButton.addEventListener('click', clearAllPanels);
    
    clearButton.addEventListener('mouseover', () => {
        clearButton.style.backgroundColor = '#a00000';
    });
    
    clearButton.addEventListener('mouseout', () => {
        clearButton.style.backgroundColor = '#8B0000';
    });
    
    // Ensamblar el contenedor principal
    controlsContainer.appendChild(stateButtonsLegend);
    controlsContainer.appendChild(stateButtonsContainer);
    controlsContainer.appendChild(clearButton);
    
    // Añadir a la página
    document.body.appendChild(controlsContainer);
    
    // Función para actualizar la UI con estados guardados
    updateStateButtons();
}

// Función para limpiar todos los paneles
function clearAllPanels() {
    // Preguntar confirmación
    if (!confirm('¿Estás seguro de que quieres eliminar todos los paneles?')) {
        return;
    }
    
    // Limpiar todos los paneles actuales
    panels.forEach(panel => {
        if(panel.group) {
            scene.remove(panel.group);
            // Limpiar geometrías de los hijos (líneas)
            while(panel.group.children.length > 0){
                const child = panel.group.children[0]; 
                panel.group.remove(child);
                if (child.geometry) child.geometry.dispose();
            }
        }
    });
    panels.length = 0; 
    currentlyHoveredPanel = null; 
    
    // Reiniciar contador de paneles
    panelOrderCounter = 1;
    
    // Flash de confirmación visual
    gridAnimationInProgress = true;
    gridAnimationStep = 2; // Solo paso de flash
    gridAnimationProgress = 0;
    gridFlashCount = 0;
    
    console.log('Todos los paneles han sido eliminados');
}

// Inicializar la interfaz de usuario después de cargar
window.addEventListener('load', () => {
    createUIControls();
    initTerminalConsole();
    controlsVisible = false;
    const controlsElement = document.getElementById('controls');
    const uiControlsElement = document.getElementById('ui-controls');
    if (controlsElement) controlsElement.style.display = 'none';
    if (uiControlsElement) uiControlsElement.style.display = 'none';
});

// Por si el documento ya está cargado
if (document.readyState === 'complete') {
    createUIControls();
    initTerminalConsole();
}

// Inicialización de la consola terminal
function initTerminalConsole() {
    const terminalInput = document.getElementById('terminal-input');
    if (!terminalInput) return;
    
    terminalInput.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
            const command = terminalInput.value.trim();
            if (command) {
                processTerminalCommand(command);
                terminalInput.value = '';
            }
            event.preventDefault();
        } else if (event.key === 'Escape') {
            // Ocultar la consola con Escape
            toggleTerminal(false);
            event.preventDefault();
        }
    });
    
    // Iniciar con un mensaje de bienvenida
    const output = document.getElementById('terminal-output');
    if (output) {
        const welcomeDiv = document.createElement('div');
        welcomeDiv.innerHTML = 'Consola de bioPrint. Escribe <b>help</b> para ver los comandos disponibles.';
        output.appendChild(welcomeDiv);
    }
}

// Función para cargar configuración desde datos
function applyConfigurationFromData(configData) {
    if (!configData || !configData.grid || !configData.panels) {
        console.error("Formato de configuración inválido");
        return false;
    }
    
    // Restablecer contador de orden global
    panelOrderCounter = 1;
    
    // Limpiar los paneles actuales
    clearAllPanels();
    
    // Aplicar configuración de la cuadrícula
    const gridParams = {
        cellSize: configData.grid.cellSize,
        cellsX: configData.grid.cellsX,
        cellsY: configData.grid.cellsY,
        halfWidth: (configData.grid.cellsX * configData.grid.cellSize) / 2,
        halfHeight: (configData.grid.cellsY * configData.grid.cellSize) / 2
    };
    
    // Regenerar cuadrícula
    regenerateGrid(gridParams);
    
    // Recrear los paneles
    for (const panelData of configData.panels) {
        // Crear panel desde datos guardados
        const panel = {
            group: null,
            minCellIndex: panelData.minCellIndex,
            maxCellIndex: panelData.maxCellIndex,
            orderNumber: panelData.orderNumber || panelOrderCounter++,
            showOrderNumber: panelData.showOrderNumber !== undefined ? panelData.showOrderNumber : true
        };
        
        // Actualizar geometría y posición
        updatePanelGeometryAndPosition(panel, gridParams);
        
        if(panel.group) {
            scene.add(panel.group);
            panels.push(panel);
            
            // Crear etiqueta con número de orden
            createPanelOrderLabel(panel);
        }
    }
    
    // Actualizar contador para nuevos paneles
    if (configData.panels.length > 0) {
        const maxOrder = Math.max(...configData.panels.map(p => p.orderNumber || 0));
        panelOrderCounter = maxOrder + 1;
    }
    
    // Restaurar posición de cámara si está disponible
    if (configData.cameraPosition) {
        camera.position.set(
            configData.cameraPosition.x,
            configData.cameraPosition.y,
            configData.cameraPosition.z
        );
    }
    
    // Restaurar zoom de cámara si está disponible
    if (configData.cameraZoom) {
        camera.zoom = configData.cameraZoom;
        camera.updateProjectionMatrix();
    }
    
    return true;
}

// Función para actualizar la lista de estados guardados en la interfaz
function updateScreenStatesList() {
    const statesList = document.getElementById('savedStatesList');
    if (!statesList) return;
    
    // Limpiar lista actual
    statesList.innerHTML = '';
    
    // Agregar cada estado guardado a la lista
    savedScreenStates.forEach((stateJson, index) => {
        try {
            const state = JSON.parse(stateJson);
            const date = state.date ? new Date(state.date).toLocaleString() : `Estado ${index + 1}`;
            
            const li = document.createElement('li');
            li.className = 'saved-state-item';
            
            // Texto del estado con fecha y número de paneles
            const stateText = document.createElement('span');
            stateText.textContent = `${date} (${state.panels?.length || 0} paneles)`;
            li.appendChild(stateText);
            
            // Botón para cargar este estado
            const loadBtn = document.createElement('button');
            loadBtn.textContent = 'Cargar';
            loadBtn.onclick = () => loadScreenState(index);
            li.appendChild(loadBtn);
            
            statesList.appendChild(li);
        } catch (e) {
            console.error("Error al procesar estado guardado:", e);
        }
    });
}

// Función para alternar la visibilidad de los números de los paneles
function togglePanelNumbers() {
    // Recorrer todos los paneles y cambiar su propiedad showOrderNumber
    panels.forEach(panel => {
        panel.showOrderNumber = !panel.showOrderNumber;
        // Actualizar la etiqueta (crear o eliminar según corresponda)
        createPanelOrderLabel(panel);
    });
    
    // Mensaje de confirmación
    console.log(`Números de panel ${panels.length > 0 && panels[0].showOrderNumber ? 'mostrados' : 'ocultados'}`);
}

// Función para mostrar u ocultar la consola terminal
function toggleTerminal(show) {
    const terminal = document.getElementById('terminal-console');
    if (!terminal) return;
    
    terminalVisible = show !== undefined ? show : !terminalVisible;
    terminal.style.display = terminalVisible ? 'block' : 'none';
    
    if (terminalVisible) {
        // Dar foco al input cuando se muestra
        const input = document.getElementById('terminal-input');
        if (input) {
            input.focus();
            // Limpiar el input al abrir
            input.value = '';
        }
    }
}

// Función para procesar comandos de la consola
function processTerminalCommand(command) {
    const [cmd, ...args] = command.trim().split(' ');
    const output = document.getElementById('terminal-output');

    switch (cmd.toLowerCase()) {
        case 'help':
            showHelp(output);
            break;
        case 'select':
            selectPanels(args, output);
            break;
        case 'show':
            showPanelNumbers(true, output);
            break;
        case 'hide':
            showPanelNumbers(false, output);
            break;
        case 'list':
            listPanels(output);
            break;
        case 'clear':
            clearTerminal(output);
            break;
        case 'delete':
            deletePanels(args, output);
            break;
        case 'logo':
            mapLogo(args, output);
            break;
        case 'txt':
            handleTextCommand(args, output);
            break;
        default:
            showError(`Comando desconocido: ${cmd}. Escribe 'help' para ver comandos disponibles.`, output);
    }
    
    // Scroll al final
    output.scrollTop = output.scrollHeight;
}

// Funciones auxiliares para los comandos
function showHelp(output) {
    const commands = [
        "help - Muestra esta ayuda",
        "select [all|number|range] - Selecciona paneles (ej: select 1-3,5,7)",
        "show - Muestra números de panel",
        "hide - Oculta números de panel",
        "list - Lista todos los paneles",
        "clear - Limpia la consola",
        "delete [all|selected|number] - Elimina paneles",
        "logo - Mapea el logo de BioPrint en el panel seleccionado"
    ];
    
    const helpText = document.createElement('div');
    helpText.innerHTML = `
        <div><b>Comandos disponibles:</b></div>
        <ul>${commands.map(cmd => `<li>${cmd}</li>`).join('')}</ul>
    `;
    output.appendChild(helpText);
}

function selectPanels(args, output) {
    if (args.length === 0 || args[0] === 'all') {
        // Seleccionar todos los paneles
        panels.forEach(panel => {
            panel.selected = true;
            updatePanelColor(panel);
        });
        showSuccess(`${panels.length} paneles seleccionados`, output);
        return;
    }
    
    // Deseleccionar todos los paneles primero
    panels.forEach(panel => {
        panel.selected = false;
        updatePanelColor(panel);
    });
    
    // Analizar los argumentos para determinar qué paneles seleccionar
    const panelsToSelect = new Set();
    
    for (const arg of args) {
        if (arg.includes('-')) {
            // Es un rango: "1-5"
            const [start, end] = arg.split('-').map(n => parseInt(n));
            for (let i = start; i <= end; i++) {
                panelsToSelect.add(i);
            }
        } else {
            // Es un número individual
            panelsToSelect.add(parseInt(arg));
        }
    }
    
    // Buscar y seleccionar los paneles por número de orden
    let selected = 0;
    panels.forEach(panel => {
        if (panelsToSelect.has(panel.orderNumber)) {
            panel.selected = true;
            updatePanelColor(panel);
            selected++;
        }
    });
    
    showSuccess(`${selected} paneles seleccionados`, output);
}

function showPanelNumbers(show, output) {
    panels.forEach(panel => {
        panel.showOrderNumber = show;
        createPanelOrderLabel(panel);
    });
    
    showSuccess(`Números de panel ${show ? 'mostrados' : 'ocultados'}`, output);
}

function listPanels(output) {
    if (panels.length === 0) {
        showInfo('No hay paneles en el diseño actual', output);
        return;
    }
    
    const listDiv = document.createElement('div');
    listDiv.innerHTML = `<div><b>Paneles (${panels.length}):</b></div>`;
    
    panels.forEach(panel => {
        const panelInfo = document.createElement('div');
        panelInfo.textContent = `Panel #${panel.orderNumber}: [${panel.minCellIndex.x},${panel.minCellIndex.y}] a [${panel.maxCellIndex.x},${panel.maxCellIndex.y}] - ${panel.selected ? '(Seleccionado)' : ''}`;
        listDiv.appendChild(panelInfo);
    });
    
    output.appendChild(listDiv);
}

function clearTerminal(output) {
    output.innerHTML = '';
}

function deletePanels(args, output) {
    if (args.length === 0) {
        showError('Especifique qué paneles eliminar: all, selected, o números', output);
        return;
    }
    
    if (args[0] === 'all') {
        // Llamar a la función existente
        clearAllPanels();
        return;
    }
    
    if (args[0] === 'selected') {
        const selectedPanels = panels.filter(p => p.selected);
        const count = selectedPanels.length;
        
        if (count === 0) {
            showInfo('No hay paneles seleccionados para eliminar', output);
            return;
        }
        
        // Eliminar los paneles seleccionados
        const remainingPanels = [];
        
        panels.forEach(panel => {
            if (panel.selected) {
                if (panel.group) {
                    scene.remove(panel.group);
                    // Limpiar geometrías
                    while (panel.group.children.length > 0) {
                        const child = panel.group.children[0];
                        panel.group.remove(child);
                        if (child.geometry) child.geometry.dispose();
                    }
                }
            } else {
                remainingPanels.push(panel);
            }
        });
        
        panels.length = 0;
        panels.push(...remainingPanels);
        
        showSuccess(`${count} paneles eliminados`, output);
        return;
    }
    
    // Si llegamos aquí, args[0] es un número o lista de números
    // Se podría implementar la eliminación por número específico si se necesita
    showError('Opción no implementada: ' + args[0], output);
}

// Funciones para mostrar mensajes en la consola
function showError(message, output) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'terminal-error';
    errorDiv.textContent = message;
    output.appendChild(errorDiv);
}

function showSuccess(message, output) {
    const successDiv = document.createElement('div');
    successDiv.className = 'terminal-success';
    successDiv.textContent = message;
    output.appendChild(successDiv);
}

function showInfo(message, output) {
    const infoDiv = document.createElement('div');
    infoDiv.textContent = message;
    output.appendChild(infoDiv);
}

// Variables para detectar la escena
let sceneInitialized = false;

// Inicializar la aplicación después de mostrar el splash screen
function initializeApp() {
    if (sceneInitialized) return;
    
    // Configuración de la escena
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x000000); // Negro

    // Variables para recordar la configuración inicial de la cámara
    const initialCameraState = {
        position: null,
        zoom: null,
        distance: null
    };
}

function mapLogo(args, output) {
    const selectedPanels = scene.children.filter(obj => obj.userData.isPanel && obj.userData.selected);
    
    if (selectedPanels.length === 0) {
        showError("No hay paneles seleccionados. Por favor, selecciona un panel primero.", output);
        return;
    }

    if (selectedPanels.length > 1) {
        showError("Por favor, selecciona solo un panel para mapear el logo.", output);
        return;
    }

    const panel = selectedPanels[0];
    const texture = new THREE.TextureLoader().load('img/bioprint_logo.png', function(texture) {
        const material = new THREE.MeshBasicMaterial({
            map: texture,
            transparent: true,
            opacity: 0.8
        });
        
        // Guardamos el material original
        panel.userData.originalMaterial = panel.material;
        panel.material = material;
        
        showSuccess("Logo mapeado exitosamente en el panel seleccionado.", output);
    });
}

// Nueva función para manejar el comando de texto
function handleTextCommand(args, output) {
    const selectedPanels = panels.filter(p => p.selected);
    
    if (selectedPanels.length === 0) {
        showError('Seleccione un panel para agregar texto', output);
        return;
    }
    
    if (selectedPanels.length > 1) {
        showError('Seleccione solo un panel para editar texto', output);
        return;
    }
    
    const panel = selectedPanels[0];
    const currentGridParams = getCurrentGridParams();
    
    if (!currentGridParams) {
        showError('No se pudo obtener la configuración del grid', output);
        return;
    }
    
    // Crear o actualizar el contenedor de texto
    createPanelText(panel, currentGridParams.cellSize);
    
    // Activar modo de edición
    startTextEditing(panel, currentGridParams.cellSize);
    
    // Agregar listeners de teclado
    const handleKeyPress = (event) => {
        handleTextInput(panel, event, currentGridParams.cellSize);
    };
    
    const handleEscape = (event) => {
        if (event.key === 'Escape') {
            stopTextEditing(panel);
            document.removeEventListener('keypress', handleKeyPress);
            document.removeEventListener('keydown', handleEscape);
        }
    };
    
    document.addEventListener('keypress', handleKeyPress);
    document.addEventListener('keydown', handleEscape);
    
    showSuccess('Modo de edición de texto activado. Presione ESC para salir.', output);
}